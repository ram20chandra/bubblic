import { FileValidator } from "../validation/FileValidator";
import { IUploadService } from "../services/IUploadService";
import {
  IFileItem,
  IFileUploadMetadata,
  serializeMetadata
} from "../models/UploadMetadata";
import { UploadProgress } from "./UploadProgress";

/**
 * Main UI component – layout matches the provided design reference.
 * allowMultiple is controlled by the PCF input property (default true).
 */
export class FileUploader {
  private container: HTMLDivElement;
  private dropZone: HTMLDivElement;
  private fileInput: HTMLInputElement;
  private fileListContainer: HTMLDivElement;
  private overallStatus: HTMLDivElement;
  private successBanner: HTMLDivElement;
  private files: Map<string, IFileItem> = new Map();
  private progressComponents: Map<string, UploadProgress> = new Map();
  private validator = new FileValidator();
  private uploadService: IUploadService;
  private onMetadataChange: (json: string) => void;
  private activeUploadIds: Map<string, string> = new Map();
  private allowMultiple: boolean;

  constructor(
    parent: HTMLElement,
    uploadService: IUploadService,
    onMetadataChange: (json: string) => void,
    allowMultiple: boolean = false
  ) {
    this.uploadService = uploadService;
    this.onMetadataChange = onMetadataChange;
    this.allowMultiple = allowMultiple;

    this.container = document.createElement("div");
    this.container.className = "du-container";
    this.container.setAttribute("role", "region");
    this.container.setAttribute("aria-label", "Document upload");

    // Header
    const header = document.createElement("div");
    header.className = "du-header";

    const title = document.createElement("h3");
    title.className = "du-title";
    title.textContent = "Upload documents";

    const badge = document.createElement("span");
    badge.className = "du-badge";
    badge.textContent = "32 MB max";

    header.appendChild(title);
    header.appendChild(badge);

    // Drop zone
    this.dropZone = document.createElement("div");
    this.dropZone.className = "du-dropzone";
    this.dropZone.setAttribute("tabindex", "0");
    this.dropZone.setAttribute("role", "button");
    this.dropZone.setAttribute(
      "aria-label",
      "Drag and drop files here or press Enter to browse"
    );

    const icon = document.createElement("div");
    icon.className = "du-dropzone-icon";
    icon.innerHTML = "☁︎";
    icon.setAttribute("aria-hidden", "true");

    const mainText = document.createElement("p");
    mainText.className = "du-dropzone-text";
    mainText.textContent = "Drag and drop your files here";

    const subText = document.createElement("p");
    subText.className = "du-dropzone-subtext";
    subText.textContent = "or browse your computer";

    const browseBtn = document.createElement("button");
    browseBtn.type = "button";
    browseBtn.className = "du-btn du-btn-browse";
    browseBtn.textContent = "Browse files";
    browseBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.fileInput.click();
    });

    this.dropZone.appendChild(icon);
    this.dropZone.appendChild(mainText);
    this.dropZone.appendChild(subText);
    this.dropZone.appendChild(browseBtn);

    this.dropZone.addEventListener("click", (e) => {
      if ((e.target as HTMLElement).tagName !== "BUTTON") {
        this.fileInput.click();
      }
    });

    // Hidden file input
    this.fileInput = document.createElement("input");
    this.fileInput.type = "file";
    this.fileInput.multiple = this.allowMultiple;
    this.fileInput.accept = ".pdf,.png,.jpg,.jpeg,.docx,.xlsx";
    this.fileInput.className = "du-file-input";
    this.fileInput.setAttribute("aria-hidden", "true");
    this.fileInput.addEventListener("change", () => this.handleFileSelect());

    // Accepted formats hint
    const accepted = document.createElement("p");
    accepted.className = "du-accepted";
    accepted.textContent = "Accepted: PDF, PNG, JPG, JPEG, DOCX, XLSX · Maximum 32 MB per file";

    // File list
    this.fileListContainer = document.createElement("div");
    this.fileListContainer.className = "du-file-list";
    this.fileListContainer.setAttribute("role", "list");
    this.fileListContainer.setAttribute("aria-label", "Selected files");

    // Success banner
    this.successBanner = document.createElement("div");
    this.successBanner.className = "du-success-banner";
    this.successBanner.style.display = "none";
    this.successBanner.innerHTML = `<span class="du-check">✓</span> Document uploaded successfully`;

    // Overall status
    this.overallStatus = document.createElement("div");
    this.overallStatus.className = "du-overall-status";
    this.overallStatus.setAttribute("aria-live", "polite");

    this.container.appendChild(header);
    this.container.appendChild(this.dropZone);
    this.container.appendChild(this.fileInput);
    this.container.appendChild(accepted);
    this.container.appendChild(this.fileListContainer);
    this.container.appendChild(this.successBanner);
    this.container.appendChild(this.overallStatus);

    parent.appendChild(this.container);

    this.attachDropHandlers();
    this.attachKeyboardHandlers();
  }

  /** Called from updateView if the form property changes */
  public setAllowMultiple(value: boolean): void {
    this.allowMultiple = value;
    this.fileInput.multiple = value;
  }

  private attachDropHandlers(): void {
    const prevent = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
    };

    this.dropZone.addEventListener("dragenter", (e) => {
      prevent(e);
      this.dropZone.classList.add("du-dropzone-active");
    });
    this.dropZone.addEventListener("dragover", (e) => {
      prevent(e);
      this.dropZone.classList.add("du-dropzone-active");
    });
    this.dropZone.addEventListener("dragleave", (e) => {
      prevent(e);
      this.dropZone.classList.remove("du-dropzone-active");
    });
    this.dropZone.addEventListener("drop", (e) => {
      prevent(e);
      this.dropZone.classList.remove("du-dropzone-active");
      if (e.dataTransfer?.files) {
        this.processFiles(Array.from(e.dataTransfer.files));
      }
    });
  }

  private attachKeyboardHandlers(): void {
    this.dropZone.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        this.fileInput.click();
      }
    });
  }

  private handleFileSelect(): void {
    if (this.fileInput.files) {
      this.processFiles(Array.from(this.fileInput.files));
      this.fileInput.value = "";
    }
  }

  private async processFiles(fileList: File[]): Promise<void> {
    let filesToProcess = fileList;

    if (!this.allowMultiple) {
      // Clear any existing file(s)
      for (const item of Array.from(this.files.values())) {
        this.removeFile(item);
      }
      filesToProcess = fileList.slice(0, 1);
    }

    for (const file of filesToProcess) {
      const already = Array.from(this.files.values()).some(
        (f) => f.file.name === file.name && f.file.size === file.size
      );
      if (already) continue;

      if (!this.allowMultiple && this.files.size >= 1) break;

      const id = `file-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      const extension = file.name.split(".").pop()?.toLowerCase() || "";

      const item: IFileItem = {
        id,
        file,
        metadata: {
          fileName: file.name,
          fileSize: file.size,
          extension,
          uploadReference: null,
          uploadStatus: "validating",
          uploadTimestamp: null,
          validationStatus: "pending",
          errorMessage: null
        },
        progress: 0,
        isUploading: false,
        canRetry: false,
        canCancel: false
      };

      this.files.set(id, item);
      this.renderFileItem(item);

      const result = await this.validator.validate(file);
      if (!result.isValid) {
        item.metadata.validationStatus = "invalid";
        item.metadata.uploadStatus = "failed";
        item.metadata.errorMessage = result.errorMessage;
        this.updateFileItemUI(item);
        this.emitMetadata();
        continue;
      }

      item.metadata.validationStatus = "valid";
      item.metadata.uploadStatus = "pending";
      this.updateFileItemUI(item);
      this.emitMetadata();
      this.startUpload(item);
    }
    this.updateOverallStatus();
  }

  private startUpload(item: IFileItem): void {
    item.isUploading = true;
    item.canCancel = true;
    item.canRetry = false;
    item.metadata.uploadStatus = "uploading";
    item.progress = 0;
    this.updateFileItemUI(item);
    this.emitMetadata();

    const uploadId = this.uploadService.upload(
      item.file,
      (progress) => {
        item.progress = progress;
        this.updateFileItemUI(item);
      },
      (result) => {
        item.isUploading = false;
        item.canCancel = false;
        item.canRetry = false;
        item.progress = 100;
        item.metadata.uploadStatus = result.status;
        item.metadata.uploadReference = result.uploadReference;
        item.metadata.uploadTimestamp = result.timestamp;
        item.metadata.errorMessage = null;
        this.activeUploadIds.delete(item.id);
        this.updateFileItemUI(item);
        this.emitMetadata();
        this.updateOverallStatus();
      },
      (error) => {
        item.isUploading = false;
        item.canCancel = false;
        item.canRetry = true;
        item.metadata.uploadStatus = "failed";
        item.metadata.errorMessage = error;
        this.activeUploadIds.delete(item.id);
        this.updateFileItemUI(item);
        this.emitMetadata();
        this.updateOverallStatus();
      }
    );

    this.activeUploadIds.set(item.id, uploadId);
  }

  private cancelUpload(item: IFileItem): void {
    const uploadId = this.activeUploadIds.get(item.id);
    if (uploadId) {
      this.uploadService.cancel(uploadId);
      this.activeUploadIds.delete(item.id);
    }
    item.isUploading = false;
    item.canCancel = false;
    item.canRetry = true;
    item.metadata.uploadStatus = "cancelled";
    item.metadata.errorMessage = "Upload cancelled by user.";
    this.updateFileItemUI(item);
    this.emitMetadata();
    this.updateOverallStatus();
  }

  private retryUpload(item: IFileItem): void {
    const previousId = this.activeUploadIds.get(item.id) || "";
    item.isUploading = true;
    item.canCancel = true;
    item.canRetry = false;
    item.metadata.uploadStatus = "uploading";
    item.metadata.errorMessage = null;
    item.progress = 0;
    this.updateFileItemUI(item);
    this.emitMetadata();

    const uploadId = this.uploadService.retry(
      item.file,
      previousId,
      (progress) => {
        item.progress = progress;
        this.updateFileItemUI(item);
      },
      (result) => {
        item.isUploading = false;
        item.canCancel = false;
        item.canRetry = false;
        item.progress = 100;
        item.metadata.uploadStatus = result.status;
        item.metadata.uploadReference = result.uploadReference;
        item.metadata.uploadTimestamp = result.timestamp;
        item.metadata.errorMessage = null;
        this.activeUploadIds.delete(item.id);
        this.updateFileItemUI(item);
        this.emitMetadata();
        this.updateOverallStatus();
      },
      (error) => {
        item.isUploading = false;
        item.canCancel = false;
        item.canRetry = true;
        item.metadata.uploadStatus = "failed";
        item.metadata.errorMessage = error;
        this.activeUploadIds.delete(item.id);
        this.updateFileItemUI(item);
        this.emitMetadata();
        this.updateOverallStatus();
      }
    );

    this.activeUploadIds.set(item.id, uploadId);
  }

  private removeFile(item: IFileItem): void {
    if (item.isUploading) {
      this.cancelUpload(item);
    }
    const prog = this.progressComponents.get(item.id);
    if (prog) {
      prog.remove();
      this.progressComponents.delete(item.id);
    }
    this.files.delete(item.id);
    this.activeUploadIds.delete(item.id);
    this.emitMetadata();
    this.updateOverallStatus();
  }

  private renderFileItem(item: IFileItem): void {
    const progress = new UploadProgress(this.fileListContainer);
    this.progressComponents.set(item.id, progress);
    this.updateFileItemUI(item);
  }

  private updateFileItemUI(item: IFileItem): void {
    const progress = this.progressComponents.get(item.id);
    if (!progress) return;

    let statusText = "";
    let statusKind: "success" | "uploading" | "error" | "pending" = "pending";

    switch (item.metadata.uploadStatus) {
      case "validating":
        statusText = "Validating…";
        statusKind = "pending";
        break;
      case "pending":
        statusText = "Ready";
        statusKind = "pending";
        break;
      case "uploading":
        statusText = "Uploading…";
        statusKind = "uploading";
        break;
      case "success":
        statusText = "Uploaded successfully";
        statusKind = "success";
        break;
      case "failed":
        statusText = item.metadata.errorMessage || "Upload failed";
        statusKind = "error";
        break;
      case "cancelled":
        statusText = "Cancelled";
        statusKind = "error";
        break;
    }

    if (item.metadata.validationStatus === "invalid") {
      statusText = item.metadata.errorMessage || "Validation failed";
      statusKind = "error";
    }

    progress.update(
      item.metadata.fileName,
      item.metadata.fileSize,
      item.metadata.extension,
      item.progress,
      statusText,
      statusKind
    );

    const buttons: { label: string; onClick: () => void; className?: string }[] = [];

    if (item.canCancel) {
      buttons.push({
        label: "Cancel",
        onClick: () => this.cancelUpload(item),
        className: "du-btn-secondary"
      });
    }
    if (item.canRetry) {
      buttons.push({
        label: "Retry",
        onClick: () => this.retryUpload(item),
        className: "du-btn-primary"
      });
    }
    if (item.metadata.uploadStatus !== "uploading") {
      buttons.push({
        label: "Remove",
        onClick: () => this.removeFile(item),
        className: "du-btn-danger"
      });
    }

    progress.setActions(buttons);
  }

  private emitMetadata(): void {
    const meta: IFileUploadMetadata[] = Array.from(this.files.values()).map(
      (f) => f.metadata
    );
    this.onMetadataChange(serializeMetadata(meta));
  }

  private updateOverallStatus(): void {
    const items = Array.from(this.files.values());
    this.successBanner.style.display = "none";
    this.overallStatus.textContent = "";
    this.overallStatus.className = "du-overall-status";

    if (items.length === 0) return;

    const success = items.filter((i) => i.metadata.uploadStatus === "success").length;
    const failed = items.filter(
      (i) =>
        i.metadata.uploadStatus === "failed" ||
        i.metadata.validationStatus === "invalid"
    ).length;
    const uploading = items.filter((i) => i.metadata.uploadStatus === "uploading").length;
    const total = items.length;

    if (uploading > 0) {
      this.overallStatus.textContent = `Uploading ${uploading} of ${total} file(s)…`;
      this.overallStatus.className = "du-overall-status du-status-uploading";
    } else if (success === total) {
      this.successBanner.style.display = "flex";
      if (total === 1) {
        this.successBanner.innerHTML = `<span class="du-check">✓</span> Document uploaded successfully`;
      } else {
        this.successBanner.innerHTML = `<span class="du-check">✓</span> All ${total} documents uploaded successfully`;
      }
    } else if (failed > 0) {
      this.overallStatus.textContent = `${success} succeeded, ${failed} failed.`;
      this.overallStatus.className = "du-overall-status du-status-error";
    }
  }

  public destroy(): void {
    for (const [, uploadId] of this.activeUploadIds) {
      this.uploadService.cancel(uploadId);
    }
    this.activeUploadIds.clear();
    this.files.clear();
    this.progressComponents.clear();
    this.container.remove();
  }
}
