/**
 * Renders a single file progress bar and status matching the target UI.
 */
export class UploadProgress {
  private container: HTMLDivElement;
  private iconEl: HTMLDivElement;
  private nameEl: HTMLSpanElement;
  private metaEl: HTMLSpanElement;
  private percentEl: HTMLSpanElement;
  private barFill: HTMLDivElement;
  private actionsEl: HTMLDivElement;

  constructor(parent: HTMLElement) {
    this.container = document.createElement("div");
    this.container.className = "du-file-item";
    this.container.setAttribute("role", "listitem");

    const row = document.createElement("div");
    row.className = "du-file-row";

    this.iconEl = document.createElement("div");
    this.iconEl.className = "du-file-icon default";
    this.iconEl.textContent = "FILE";

    const info = document.createElement("div");
    info.className = "du-file-info";

    this.nameEl = document.createElement("div");
    this.nameEl.className = "du-file-name";

    this.metaEl = document.createElement("div");
    this.metaEl.className = "du-file-meta";

    info.appendChild(this.nameEl);
    info.appendChild(this.metaEl);

    this.percentEl = document.createElement("span");
    this.percentEl.className = "du-file-percent";

    row.appendChild(this.iconEl);
    row.appendChild(info);
    row.appendChild(this.percentEl);

    const progressWrapper = document.createElement("div");
    progressWrapper.className = "du-progress-wrapper";
    progressWrapper.setAttribute("role", "progressbar");
    progressWrapper.setAttribute("aria-valuemin", "0");
    progressWrapper.setAttribute("aria-valuemax", "100");

    this.barFill = document.createElement("div");
    this.barFill.className = "du-progress-fill";
    progressWrapper.appendChild(this.barFill);

    this.actionsEl = document.createElement("div");
    this.actionsEl.className = "du-file-actions";

    this.container.appendChild(row);
    this.container.appendChild(progressWrapper);
    this.container.appendChild(this.actionsEl);

    parent.appendChild(this.container);
  }

  update(
    fileName: string,
    fileSize: number,
    extension: string,
    progress: number,
    statusText: string,
    statusKind: "success" | "uploading" | "error" | "pending"
  ): void {
    this.nameEl.textContent = fileName;
    this.metaEl.textContent = `${this.formatSize(fileSize)} · ${statusText}`;

    // Icon
    const ext = (extension || "").toLowerCase();
    this.iconEl.className = `du-file-icon ${["pdf","png","jpg","jpeg","docx","xlsx"].includes(ext) ? ext : "default"}`;
    this.iconEl.textContent = ext === "jpeg" ? "JPG" : (ext || "FILE").toUpperCase().slice(0, 4);

    // Percent
    this.percentEl.textContent = statusKind === "success" ? "100%" : `${Math.floor(progress)}%`;
    this.percentEl.className = `du-file-percent ${statusKind === "uploading" ? "uploading" : statusKind === "error" ? "error" : ""}`;

    // Bar
    this.barFill.style.width = `${Math.min(100, Math.max(0, progress))}%`;
    this.barFill.className = `du-progress-fill ${statusKind === "uploading" ? "uploading" : statusKind === "error" ? "error" : ""}`;
    this.container.querySelector(".du-progress-wrapper")?.setAttribute("aria-valuenow", String(Math.floor(progress)));
  }

  setActions(buttons: { label: string; onClick: () => void; className?: string }[]): void {
    this.actionsEl.innerHTML = "";
    for (const btn of buttons) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = `du-btn ${btn.className || "du-btn-secondary"}`;
      b.textContent = btn.label;
      b.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        btn.onClick();
      });
      this.actionsEl.appendChild(b);
    }
  }

  remove(): void {
    this.container.remove();
  }

  private formatSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
}
