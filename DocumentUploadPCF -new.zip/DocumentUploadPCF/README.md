# Document Upload PCF Control

Production-ready Power Apps Component Framework (PCF) control for multi-file (or single-file) document upload.  
Compatible with Dynamics 365 model-driven apps and Power Pages.

**Publisher:** gac

## Features

- Drag-and-drop + browse upload
- Multi-layer validation (extension, MIME, magic bytes, OOXML structure)
- Per-file progress, cancel, retry, remove
- Configurable **Allow Multiple** property (form designer)
- Mock Azure Blob upload service with clean `IUploadService` abstraction
- Bound `uploadMetadata` text property returning JSON metadata (no file content)
- Accessible (keyboard, ARIA)
- Responsive modern UI

## Allowed files

| Extension | Max size |
|-----------|----------|
| PDF, PNG, JPG, JPEG, DOCX, XLSX | 32 MB |

## PCF Properties

| Property | Type | Usage | Description |
|----------|------|-------|-------------|
| `uploadMetadata` | Single line of text | Bound | JSON array of upload metadata |
| `allowMultiple` | Two options | Input | `false` = single file only (default), `true` = multi-file |

## Project structure

```
DocumentUploadPCF/
├── ControlManifest.Input.xml
├── index.ts
├── package.json
├── tsconfig.json
├── jest.config.js
├── README.md
├── components/
│   ├── FileUploader.ts
│   └── UploadProgress.ts
├── validation/
│   ├── FileValidator.ts
│   └── OfficeFileValidator.ts
├── services/
│   ├── IUploadService.ts
│   └── MockBlobUploadService.ts
├── models/
│   └── UploadMetadata.ts
├── css/
│   └── DocumentUpload.css
├── tests/
│   └── FileValidator.test.ts
├── generated/
│   └── ManifestTypes.ts
└── scripts/
    └── Create-Zip.ps1
```

## Prerequisites

- Node.js 16+ (LTS recommended)
- Power Platform CLI (`pac`)

## Local development

```bash
cd DocumentUploadPCF
npm install
npm run build
npm test
npm start
```

## Packaging as a solution (publisher: gac)

```bash
# From the PCF project folder after a successful build
pac solution init --publisher-name gac --publisher-prefix gac
pac solution add-reference --path .
pac solution build
```

Import the resulting solution into the target environment.

## Adding the control to a model-driven form

1. Open the form in the form designer.
2. Select the text field that will hold the metadata.
3. Properties → Components → + Component → select **DocumentUpload**.
4. Configure the **Allow Multiple** property:
   - Yes / true → multiple files
   - No / false → single file only (default)
5. Save and publish the form.

## Power Pages

1. Deploy the solution containing the PCF.
2. In Power Pages design studio open the form.
3. Enable the custom component on the field.
4. Publish the site.

## Dataverse field recommendation

Prefer a **Multiple lines of text** column for `uploadMetadata` when using multi-file mode.

## Azure Blob integration (ready to plug in)

The control already contains a production-ready skeleton:

- `services/IUploadService.ts` – interface
- `services/MockBlobUploadService.ts` – local testing (default)
- `services/AzureBlobUploadService.ts` – real Azure implementation (placeholder)

### How to connect your Azure resources

1. Open **`index.ts`** and fill in the config block:

```ts
const USE_AZURE_UPLOAD = true;   // flip this when ready

const AZURE_CONFIG = {
  uploadApiEndpoint: "https://YOUR-API.azurewebsites.net/api/upload",
  containerName: "YOUR-CONTAINER-NAME",       // e.g. "quarantine"
  storageAccountName: "YOUR-STORAGE-ACCOUNT", // e.g. "stgdocuploadprod"
  timeoutMs: 120000
};
```

2. Open **`services/AzureBlobUploadService.ts`** and complete the two TODO sections:
   - Request a short-lived SAS URL from your authenticated API
   - PUT the file to the SAS URL (or POST to your API)

3. Rebuild and redeploy the PCF.

### Recommended architecture

```
PCF → Authenticated Upload API → issues short-lived SAS
    → PUT file to Azure Blob (quarantine container)
    → Microsoft Defender for Storage scan
    → Event Grid → Power Automate
         ├─ Clean → SharePoint via Graph API
         └─ Malicious / inconclusive → Reject
    → Update Dataverse metadata
```

**Rules already enforced by design**
- No storage account keys or connection strings in the PCF
- Short-lived, authenticated upload authorization only
- Private quarantine containers
- Never promote to SharePoint before a confirmed clean scan
- Backend must re-validate every file

## License

MIT
