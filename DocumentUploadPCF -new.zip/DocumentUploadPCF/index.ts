import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { FileUploader } from "./components/FileUploader";
import { MockBlobUploadService } from "./services/MockBlobUploadService";
import { AzureBlobUploadService } from "./services/AzureBlobUploadService";
import { IUploadService } from "./services/IUploadService";

/**
 * ============================================================
 *  SWITCH BETWEEN MOCK AND REAL AZURE UPLOAD
 * ============================================================
 *
 * Set USE_AZURE_UPLOAD = true once you have filled in the
 * configuration in services/AzureBlobUploadService.ts
 * (and your backend SAS / upload API is ready).
 *
 * false → MockBlobUploadService  (local testing, no network)
 * true  → AzureBlobUploadService (real uploads)
 */
const USE_AZURE_UPLOAD = false;

/**
 * ============================================================
 *  AZURE CONFIGURATION – FILL THESE IN
 * ============================================================
 *
 * These values are passed to AzureBlobUploadService.
 * Prefer loading the upload API endpoint from a secure source
 * rather than hard-coding production URLs if possible.
 */
const AZURE_CONFIG = {
  // Required: your authenticated upload / SAS API
  uploadApiEndpoint: "https://YOUR-API.azurewebsites.net/api/upload",

  // Logical names (used for logging / documentation)
  // The real container is decided by your backend when it issues the SAS.
  containerName: "YOUR-CONTAINER-NAME",          // e.g. "quarantine"
  storageAccountName: "YOUR-STORAGE-ACCOUNT",    // e.g. "stgdocuploadprod"

  timeoutMs: 120000
};

/**
 * DocumentUpload PCF Control
 * Publisher: gac
 */
export class DocumentUpload implements ComponentFramework.StandardControl<IInputs, IOutputs> {
  private container: HTMLDivElement;
  private notifyOutputChanged: () => void;
  private uploader: FileUploader | null = null;
  private currentMetadataJson: string = "[]";
  private uploadService: IUploadService;
  private allowMultiple: boolean = false;

  constructor() {
    if (USE_AZURE_UPLOAD) {
      this.uploadService = new AzureBlobUploadService(AZURE_CONFIG);
    } else {
      this.uploadService = new MockBlobUploadService();
    }
  }

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    _state: ComponentFramework.Dictionary,
    container: HTMLDivElement
  ): void {
    this.container = container;
    this.notifyOutputChanged = notifyOutputChanged;

    // defaults to false (single file)
    this.allowMultiple = context.parameters.allowMultiple?.raw === true;

    if (context.parameters.uploadMetadata.raw) {
      this.currentMetadataJson = context.parameters.uploadMetadata.raw;
    }

    this.uploader = new FileUploader(
      this.container,
      this.uploadService,
      (json: string) => {
        this.currentMetadataJson = json;
        this.notifyOutputChanged();
      },
      this.allowMultiple
    );
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {
    const newAllow = context.parameters.allowMultiple?.raw === true;
    if (newAllow !== this.allowMultiple && this.uploader) {
      this.allowMultiple = newAllow;
      this.uploader.setAllowMultiple(newAllow);
    }
  }

  public getOutputs(): IOutputs {
    return {
      uploadMetadata: this.currentMetadataJson
    };
  }

  public destroy(): void {
    if (this.uploader) {
      this.uploader.destroy();
      this.uploader = null;
    }
  }
}
