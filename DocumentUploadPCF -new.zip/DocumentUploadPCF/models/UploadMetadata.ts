/**
 * UploadMetadata represents the structured output stored in the bound Dataverse text field.
 * NOTE: Dataverse SingleLine.Text has a default max length of 100 characters for some columns,
 * but can be configured up to 4,000. For multiple files, consider using Multiple lines of text
 * (max 1,048,576) or a related custom table. This control serializes an array of metadata objects.
 */
export interface IFileUploadMetadata {
  fileName: string;
  fileSize: number;
  extension: string;
  uploadReference: string | null;
  uploadStatus: UploadStatus;
  uploadTimestamp: string | null;
  validationStatus: ValidationStatus;
  errorMessage: string | null;
}

export type UploadStatus =
  | "pending"
  | "validating"
  | "uploading"
  | "success"
  | "failed"
  | "cancelled";

export type ValidationStatus =
  | "pending"
  | "valid"
  | "invalid";

export interface IUploadProgress {
  fileId: string;
  progress: number; // 0-100
  status: UploadStatus;
  errorMessage?: string;
}

export interface IFileItem {
  id: string;
  file: File;
  metadata: IFileUploadMetadata;
  progress: number;
  isUploading: boolean;
  canRetry: boolean;
  canCancel: boolean;
}

/**
 * Serializes the metadata array to a JSON string suitable for the bound text property.
 * Keep the payload under the column size limit (recommend Multiple lines of text for production).
 */
export function serializeMetadata(items: IFileUploadMetadata[]): string {
  return JSON.stringify(items);
}

export function deserializeMetadata(json: string | null): IFileUploadMetadata[] {
  if (!json || json.trim() === "") {
    return [];
  }
  try {
    const parsed = JSON.parse(json);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
