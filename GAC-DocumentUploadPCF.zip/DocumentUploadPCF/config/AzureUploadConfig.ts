/**
 * Azure upload configuration.
 *
 * Values for this build: publisher prefix "gac", storage account "gadkalyanstorageaccount",
 * container "quarantine".
 *
 * useMockService is TRUE for the first install so you can check the control on a form without
 * Azure/Dataverse being ready (a blue "Test mode" banner is shown). Once the Dataverse table,
 * storage account and flows exist, set useMockService to false and rebuild.
 * (Full explanation of every value: docs/AZURE-UPLOAD-SETUP.md, section 1.)
 *
 * The control never talks to Azure with a secret. Flow:
 *   1. it creates a small "Upload Request" row in Dataverse (metadata only, no file),
 *   2. a Power Automate flow (Flow 1) puts a short-lived write-only SAS URL on that row,
 *   3. the control uploads the file straight to that blob URL,
 *   4. Defender for Storage scans it and Flow 2 moves clean files to SharePoint and writes
 *      the final status back to the same row, which the control is waiting on.
 */

export interface IAzureUploadConfig {
  /** true = simulate uploads (no Dataverse / Azure calls; a "Test mode" banner is shown). false = real uploads. */
  useMockService: boolean;

  /** PLACEHOLDER 1 - publisher customization prefix of the solution that holds the Upload Request table, e.g. "cntso". */
  publisherPrefix: string;

  /** PLACEHOLDER 2 - Azure storage account name (not the URL), e.g. "contosodocs". */
  storageAccountName: string;

  /** PLACEHOLDER 3 - blob container the SAS URLs point at, e.g. "quarantine". */
  containerName: string;

  /**
   * Only change these two if your Upload Request table is NOT named "<prefix>_uploadrequest".
   * Leave empty to derive them from the prefix:
   *   table logical name  -> "<prefix>_uploadrequest"
   *   Web API entity set  -> "<prefix>_uploadrequests"
   */
  tableLogicalName: string;
  entitySetName: string;

  /**
   * Where the control is running.
   *   "auto"         - detect (Power Pages if the portal `shell` object exists, otherwise model-driven)
   *   "modelDriven"  - D365 / model-driven app: uses context.webAPI
   *   "powerPages"   - Power Pages: uses the portal Web API (/_api) with the CSRF token
   */
  hostMode: "auto" | "modelDriven" | "powerPages";

  /** Power Pages only: URL query-string parameter holding the current record id on edit pages (usually "id"). */
  recordIdQueryParam: string;

  /**
   * true  = after the blob upload, keep the row in "Scanning..." until Flow 2 reports the
   *         Defender result, and only then show success / failure (recommended).
   * false = show "Uploaded" as soon as the blob upload finishes (the scan still happens later).
   */
  waitForScanResult: boolean;

  /** How often to re-read the Upload Request row while waiting. */
  pollIntervalMs: number;
  /** Max wait for Flow 1 to return the SAS URL. */
  sasTimeoutMs: number;
  /** Max wait for the Defender scan + Flow 2 result. */
  scanTimeoutMs: number;
  /** Block size for large uploads. Files at or below this size are sent in one request. */
  blockSizeBytes: number;
}

export const AzureUploadConfig: IAzureUploadConfig = {
  useMockService: true, // TEST MODE. Set to false for real uploads (see header comment).

  publisherPrefix: "gac",
  storageAccountName: "gadkalyanstorageaccount",
  containerName: "quarantine",

  tableLogicalName: "",
  entitySetName: "",

  hostMode: "auto",
  recordIdQueryParam: "id",

  waitForScanResult: true,
  pollIntervalMs: 2000,
  sasTimeoutMs: 2 * 60 * 1000,
  scanTimeoutMs: 5 * 60 * 1000,
  blockSizeBytes: 4 * 1024 * 1024
};

/** Status values stored in the Upload Request "status" text column. Flow 1 / Flow 2 must use exactly these. */
export const UploadRequestStatus = {
  Requested: "Requested", // created by the control
  SasIssued: "SasIssued", // Flow 1 wrote the SAS URL
  Clean: "Clean", // Flow 2: scan clean and copied to SharePoint
  Infected: "Infected", // Flow 2: Defender flagged the file
  Rejected: "Rejected", // Flow 1: failed validation (extension, size, table, ...)
  Failed: "Failed", // any flow error / timeout
  Cancelled: "Cancelled" // user cancelled in the control
};

export interface IUploadRequestSchema {
  tableLogicalName: string;
  entitySetName: string;
  columns: {
    name: string; // primary name column
    targetTable: string;
    targetRecordId: string;
    fileName: string;
    fileSize: string;
    contentType: string;
    status: string;
    sasUrl: string;
    blobName: string;
    errorMessage: string;
    sharePointUrl: string;
  };
}

/** Derives the table + column logical names from the publisher prefix (or the overrides). */
export function getUploadRequestSchema(cfg: IAzureUploadConfig): IUploadRequestSchema {
  const p = cfg.publisherPrefix.trim().toLowerCase();
  return {
    tableLogicalName: cfg.tableLogicalName || `${p}_uploadrequest`,
    entitySetName: cfg.entitySetName || `${p}_uploadrequests`,
    columns: {
      name: `${p}_name`,
      targetTable: `${p}_targettable`,
      targetRecordId: `${p}_targetrecordid`,
      fileName: `${p}_filename`,
      fileSize: `${p}_filesize`,
      contentType: `${p}_contenttype`,
      status: `${p}_status`,
      sasUrl: `${p}_sasurl`,
      blobName: `${p}_blobname`,
      errorMessage: `${p}_errormessage`,
      sharePointUrl: `${p}_sharepointurl`
    }
  };
}

/** Returns the names of required settings that are still empty or still contain a <<PLACEHOLDER>>. */
export function findUnresolvedPlaceholders(cfg: IAzureUploadConfig): string[] {
  const required: Array<[string, string]> = [
    ["publisherPrefix", cfg.publisherPrefix],
    ["storageAccountName", cfg.storageAccountName],
    ["containerName", cfg.containerName]
  ];
  const missing: string[] = [];
  for (const [name, value] of required) {
    const v = (value || "").trim();
    if (v === "" || v.indexOf("<<") !== -1 || v.indexOf(">>") !== -1) {
      missing.push(name);
    }
  }
  return missing;
}
