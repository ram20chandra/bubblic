/**
 * Fallback defaults, used only when the "Allow multiple files (Y/N)" control
 * parameter is not set on the form.
 *
 * Central switches for the Document Upload control.
 * Edit the values here and rebuild – no other file needs to change.
 */
export interface IUploadConfig {
  /**
   * true  -> users can select / drop several files at once.
   * false -> single-file mode (default):
   *            - the file picker only allows one selection
   *            - dropping more than one file is rejected with a message
   *            - the drop zone is locked while a file is being validated,
   *              uploaded or has been uploaded; the user must remove it first
   *              (a failed / cancelled / invalid file is replaced automatically)
   */
  allowMultiple: boolean;
}

export const UploadConfig: IUploadConfig = {
  allowMultiple: false
};
