import JSZip from "jszip";
import { ValidationResult } from "./FileValidator";

/**
 * Validates internal structure of DOCX and XLSX (ZIP-based OOXML packages).
 * Rejects macro-enabled packages and missing required parts.
 */
export class OfficeFileValidator {
  async validate(file: File, extension: "docx" | "xlsx"): Promise<ValidationResult> {
    try {
      const zip = await JSZip.loadAsync(file);

      // Reject macro-enabled formats if they somehow pass extension check
      const macroIndicators = [
        "word/vbaProject.bin",
        "xl/vbaProject.bin",
        "word/vbaData.xml",
        "xl/vbaData.xml"
      ];
      for (const indicator of macroIndicators) {
        if (zip.file(indicator)) {
          return {
            isValid: false,
            errorMessage: "Invalid Office document structure.",
            extension
          };
        }
      }

      if (extension === "docx") {
        return this.validateDocx(zip, extension);
      } else {
        return this.validateXlsx(zip, extension);
      }
    } catch (err) {
      return {
        isValid: false,
        errorMessage: "Invalid Office document structure.",
        extension
      };
    }
  }

  private validateDocx(zip: JSZip, extension: string): ValidationResult {
    // Required: [Content_Types].xml, word/document.xml, _rels/.rels
    const required = [
      "[Content_Types].xml",
      "word/document.xml",
      "_rels/.rels"
    ];

    for (const path of required) {
      if (!zip.file(path)) {
        return {
          isValid: false,
          errorMessage: "Invalid Office document structure.",
          extension
        };
      }
    }

    // Content Types should declare the Word document part
    // We do a lightweight check; deeper XML parsing is left to server-side.
    return { isValid: true, errorMessage: null, extension };
  }

  private validateXlsx(zip: JSZip, extension: string): ValidationResult {
    const required = [
      "[Content_Types].xml",
      "xl/workbook.xml",
      "_rels/.rels"
    ];

    for (const path of required) {
      if (!zip.file(path)) {
        return {
          isValid: false,
          errorMessage: "Invalid Office document structure.",
          extension
        };
      }
    }

    return { isValid: true, errorMessage: null, extension };
  }
}
