import { OfficeFileValidator } from "./OfficeFileValidator";

export const MAX_FILE_SIZE_BYTES = 32 * 1024 * 1024; // 32 MB

export const ALLOWED_EXTENSIONS = ["pdf", "png", "jpg", "jpeg", "docx", "xlsx"];

export const EXTENSION_MIME_MAP: Record<string, string[]> = {
  pdf: ["application/pdf"],
  png: ["image/png"],
  jpg: ["image/jpeg"],
  jpeg: ["image/jpeg"],
  docx: [
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/zip" // some browsers report zip for Office files
  ],
  xlsx: [
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/zip"
  ]
};

export interface ValidationResult {
  isValid: boolean;
  errorMessage: string | null;
  extension: string;
}

/**
 * Multi-layer client-side validator.
 * Server-side validation MUST still be performed by the future upload API.
 */
export class FileValidator {
  private officeValidator = new OfficeFileValidator();

  async validate(file: File): Promise<ValidationResult> {
    // 1. Empty file
    if (file.size === 0) {
      return {
        isValid: false,
        errorMessage: "Empty files are not allowed.",
        extension: this.getExtension(file.name)
      };
    }

    // 2. Size
    if (file.size > MAX_FILE_SIZE_BYTES) {
      return {
        isValid: false,
        errorMessage: "File exceeds 32 MB.",
        extension: this.getExtension(file.name)
      };
    }

    // 3. Extension
    const extension = this.getExtension(file.name);
    if (!ALLOWED_EXTENSIONS.includes(extension)) {
      return {
        isValid: false,
        errorMessage: "Unsupported file extension.",
        extension
      };
    }

    // 4. MIME type (when available)
    const expectedMimes = EXTENSION_MIME_MAP[extension] || [];
    if (file.type && file.type !== "" && !expectedMimes.includes(file.type.toLowerCase())) {
      return {
        isValid: false,
        errorMessage: "MIME type does not match the extension.",
        extension
      };
    }

    // 5. Magic-byte / signature validation
    const signatureResult = await this.validateSignature(file, extension);
    if (!signatureResult.isValid) {
      return signatureResult;
    }

    // 6. Office structure validation for DOCX/XLSX
    if (extension === "docx" || extension === "xlsx") {
      const officeResult = await this.officeValidator.validate(file, extension);
      if (!officeResult.isValid) {
        return officeResult;
      }
    }

    return {
      isValid: true,
      errorMessage: null,
      extension
    };
  }

  private getExtension(fileName: string): string {
    const parts = fileName.toLowerCase().split(".");
    return parts.length > 1 ? parts[parts.length - 1] : "";
  }

  private async validateSignature(file: File, extension: string): Promise<ValidationResult> {
    const buffer = await this.readFileHeader(file, 16);
    const bytes = new Uint8Array(buffer);

    switch (extension) {
      case "pdf":
        // %PDF-
        if (
          bytes[0] === 0x25 &&
          bytes[1] === 0x50 &&
          bytes[2] === 0x44 &&
          bytes[3] === 0x46 &&
          bytes[4] === 0x2d
        ) {
          return { isValid: true, errorMessage: null, extension };
        }
        return {
          isValid: false,
          errorMessage: "Invalid PDF signature.",
          extension
        };

      case "png":
        // 89 50 4E 47 0D 0A 1A 0A
        if (
          bytes[0] === 0x89 &&
          bytes[1] === 0x50 &&
          bytes[2] === 0x4e &&
          bytes[3] === 0x47 &&
          bytes[4] === 0x0d &&
          bytes[5] === 0x0a &&
          bytes[6] === 0x1a &&
          bytes[7] === 0x0a
        ) {
          return { isValid: true, errorMessage: null, extension };
        }
        return {
          isValid: false,
          errorMessage: "Invalid image signature.",
          extension
        };

      case "jpg":
      case "jpeg":
        // FF D8 FF
        if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
          return { isValid: true, errorMessage: null, extension };
        }
        return {
          isValid: false,
          errorMessage: "Invalid image signature.",
          extension
        };

      case "docx":
      case "xlsx":
        // ZIP local file header 50 4B 03 04
        if (
          bytes[0] === 0x50 &&
          bytes[1] === 0x4b &&
          bytes[2] === 0x03 &&
          bytes[3] === 0x04
        ) {
          return { isValid: true, errorMessage: null, extension };
        }
        return {
          isValid: false,
          errorMessage: "Invalid Office document structure.",
          extension
        };

      default:
        return {
          isValid: false,
          errorMessage: "File validation failed.",
          extension
        };
    }
  }

  private readFileHeader(file: File, length: number): Promise<ArrayBuffer> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      const blob = file.slice(0, length);
      reader.onload = () => {
        if (reader.result instanceof ArrayBuffer) {
          resolve(reader.result);
        } else {
          reject(new Error("Failed to read file header."));
        }
      };
      reader.onerror = () => reject(new Error("File read error."));
      reader.readAsArrayBuffer(blob);
    });
  }
}
