# Install and test - GAC Document Upload

Values already set in this build

| Setting | Value |
|---|---|
| Publisher / prefix | **GAC** / **`gac`** |
| Control name in Dataverse | `gac_GAC.DocumentUpload` (namespace `GAC`, control `DocumentUpload`) |
| Storage account | `gadkalyanstorageaccount` |
| Container | `quarantine` (change in `config/AzureUploadConfig.ts` if you use another name) |
| Mode on first install | **Test mode** (`useMockService: true`) - uploads are simulated, a blue banner says so |

You do it in two phases so you can see the control working before any Azure work.

---

## Phase A - install the control and check it on a form (about 15 minutes, nothing else needed)

**0. Tools (once):** Node.js LTS, the Power Platform CLI (`pac`), and the .NET SDK 6+.
(`dotnet tool install --global Microsoft.PowerApps.CLI.Tool` installs `pac`.)

**1. Unzip** this project, open PowerShell in the folder.

**2. Build**
```powershell
.\scripts\Build.ps1
```
This generates the `.pcfproj` with your own `pac`, runs `npm install` and `npm run build`.
If the build fails, send me the full output.

**3. Create the publisher** (once) - make.powerapps.com → **Solutions → Publishers → New publisher**:
Display name `GAC`, Name `gac`, **Prefix `gac`**. Then create an unmanaged solution called `GACDocumentUpload`
that uses this publisher.

**4. Import the control** - pick one:

*Quick dev import*
```powershell
.\scripts\Push.ps1 -EnvironmentUrl https://YOURORG.crm.dynamics.com
```
(you sign in in a browser; it shows the environment it connected to before pushing)

*Solution zip (what you will use for UAT / production)*
```powershell
.\scripts\Create-Solution.ps1            # unmanaged zip for dev/test
.\scripts\Create-Solution.ps1 -Managed   # managed zip for UAT/prod
```
Then import the `.zip` it prints at make.powerapps.com → Solutions → **Import solution**, and **Publish all customizations**.

**5. Put it on a form (D365)**
1. Add a **Single line of text** column to your table (e.g. `gac_uploadmetadata`, max length 4000) - this stores the list of uploaded files.
2. make.powerapps.com → Tables → your table → Forms → edit the main form → add that column.
3. Select the column → **Components → + Component** → **GAC Document Upload** → tick **Web**.
4. Set **Allow multiple files (Y/N)** to `Y` or `N` (blank = `N`).
5. **Save and Publish** the form.

**6. Test** - open a record. You should see the upload card with a blue **Test mode** banner.
Drop a PDF: it shows progress and "Document uploaded successfully" (simulated; about 15% of tries fail
on purpose to test Retry). Try a `.exe` (rejected), a fake PDF (rejected), and, with `Y`, several files at once.

---

## Phase B - real uploads to Azure (follow `docs/AZURE-UPLOAD-SETUP.md`)

1. **Dataverse table:** create *Upload Request* (script: `.\scripts\Create-UploadRequestTable.ps1 -OrgUrl https://YOURORG.crm.dynamics.com -SolutionUniqueName GACDocumentUpload`
   - needs `az login`; or create it by hand using the column list in the guide section 2).
   Give your users a security role with Create/Read/Write on it.
2. **Azure** (guide section 3): storage account `gadkalyanstorageaccount`, containers `quarantine` and `infected`, the **CORS rule
   with your D365 URL**, Defender for Storage malware scanning, Event Grid topic.
3. **Flow 1** (section 4). Test it on its own first.
4. **Go live in the control:** in `config/AzureUploadConfig.ts` change `useMockService: true` to `false`, then
   `.\scripts\Build.ps1` and push/import again. **Raise the version** in `ControlManifest.Input.xml` first
   (e.g. `1.0.1`) so the environment takes the new build. The Test-mode banner disappears.
5. **Flow 2** (section 5) - scan result → SharePoint → link on the record. **Flow 3** (section 6) - cleanup.
6. **Power Pages** (section 7): site settings, table permission, and the *Target table logical name* parameter.

## What you still need to supply

| What | Where it goes |
|---|---|
| Your D365 org URL | `Push.ps1 -EnvironmentUrl`, and the Azure CORS rule |
| Your Power Pages site URL | the Azure CORS rule |
| Entra tenant ID, Graph app client ID + secret | Flow 2 HTTP action |
| SharePoint site ID, library (drive) ID, folder | Flow 2 HTTP action |
| Alert email, list of tables users can attach files to | Flows 1 and 2 |
| Name of the link column on your record | Flow 2 |

## Honest status of this package

- The UI, single/multi-file switch, Azure upload logic and the D365 / Power Pages Dataverse clients were
  run and tested in a real browser against simulated Dataverse and Blob services.
- **Not run by the author:** `npm install` / `pcf-scripts build`, the PowerShell scripts, an import into a
  real environment, Defender, the flows, SharePoint/Graph, and Power Pages. Expect to fix small things on
  the first real run - send me any error text and I will correct it.
