/** @type {import('jest').Config} */
module.exports = {
  preset: "ts-jest",
  testEnvironment: "jsdom",
  roots: ["<rootDir>/tests"],
  testMatch: ["**/*.test.ts"],
  moduleFileExtensions: ["ts", "js", "json"],
  transform: {
    "^.+\\.ts$": [
      "ts-jest",
      {
        tsconfig: {
          module: "commonjs",
          target: "es2017",
          esModuleInterop: true,
          strict: true,
          skipLibCheck: true
        }
      }
    ]
  },
  collectCoverageFrom: [
    "validation/**/*.ts",
    "services/**/*.ts",
    "!**/*.d.ts"
  ]
};
