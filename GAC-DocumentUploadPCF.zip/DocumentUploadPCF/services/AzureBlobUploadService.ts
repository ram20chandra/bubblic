import { IUploadService, UploadResult } from "./IUploadService";
import { IDataverseClient } from "./dataverse/IDataverseClient";
import {
  IAzureUploadConfig,
  UploadRequestStatus,
  findUnresolvedPlaceholders,
  getUploadRequestSchema
} from "../config/AzureUploadConfig";
import {
  UploadControl,
  newUploadControl,
  cancelControl,
  cancelledError,
  isCancelledError,
  uploadToSas
} from "./BlobUploader";

export interface ITargetRecord {
  /** Logical name of the record the document belongs to, e.g. "account". */
  table: string;
  /** Row id (GUID) of that record. */
  recordId: string;
}

export interface AzureBlobUploadServiceDeps {
  config: IAzureUploadConfig;
  client: IDataverseClient;
  /** Returns the record the file should be attached to, or null if it isn't saved yet. */
  resolveTarget: () => ITargetRecord | null;
}

interface ActiveUpload {
  ctl: UploadControl;
  rowId: string | null;
}

const MAX_FILE_NAME_LENGTH = 200;

/**
 * Real upload service. Per file:
 *  1. creates an Upload Request row (metadata only - never the file) in Dataverse,
 *  2. waits for Flow 1 to write a write-only SAS URL on the row,
 *  3. PUTs the file straight to Blob Storage with that URL,
 *  4. (optional) waits for Flow 2 to report the Defender scan + SharePoint result on the row.
 *
 * Implements the same IUploadService as MockBlobUploadService, so the UI is unchanged.
 */
export class AzureBlobUploadService implements IUploadService {
  private uploads: Map<string, ActiveUpload> = new Map();
  private nextId = 1;

  constructor(private deps: AzureBlobUploadServiceDeps) {}

  upload(
    file: File,
    onProgress: (progress: number) => void,
    onComplete: (result: UploadResult) => void,
    onError: (error: string) => void,
    onStatus?: (text: string) => void
  ): string {
    const uploadId = `azure-upload-${this.nextId++}-${Date.now()}`;
    const active: ActiveUpload = { ctl: newUploadControl(), rowId: null };
    this.uploads.set(uploadId, active);

    this.run(file, active, onProgress, onComplete, onError, onStatus || (() => {})).then(
      () => {
        this.uploads.delete(uploadId);
      },
      () => {
        this.uploads.delete(uploadId);
      }
    );
    return uploadId;
  }

  cancel(uploadId: string): void {
    const active = this.uploads.get(uploadId);
    if (!active) return;
    cancelControl(active.ctl);
    this.uploads.delete(uploadId);
    this.markRow(active, {
      [getUploadRequestSchema(this.deps.config).columns.status]: UploadRequestStatus.Cancelled
    });
  }

  retry(
    file: File,
    previousUploadId: string,
    onProgress: (progress: number) => void,
    onComplete: (result: UploadResult) => void,
    onError: (error: string) => void,
    onStatus?: (text: string) => void
  ): string {
    this.cancel(previousUploadId);
    return this.upload(file, onProgress, onComplete, onError, onStatus);
  }

  // ------------------------------------------------------------------

  private async run(
    file: File,
    active: ActiveUpload,
    onProgress: (progress: number) => void,
    onComplete: (result: UploadResult) => void,
    onError: (error: string) => void,
    onStatus: (text: string) => void
  ): Promise<void> {
    const { config, client } = this.deps;
    const schema = getUploadRequestSchema(config);
    const c = schema.columns;
    // Once the file is in Blob Storage, Flow 2 owns the row's status. From then on we must not
    // mark the row Failed (a timeout here would make Flow 2 skip a file that is still being scanned).
    let stage: "prepare" | "upload" | "scan" = "prepare";

    try {
      const missing = findUnresolvedPlaceholders(config);
      if (missing.length > 0) {
        throw new Error(
          `Upload is not configured yet. Set ${missing.join(", ")} in config/AzureUploadConfig.ts ` +
            "(or set useMockService to true to simulate uploads)."
        );
      }
      if (file.name.length > MAX_FILE_NAME_LENGTH) {
        throw new Error(`The file name is too long (maximum ${MAX_FILE_NAME_LENGTH} characters).`);
      }
      const target = this.deps.resolveTarget();
      if (!target) {
        throw new Error("Save the record first, then upload documents.");
      }

      // 1. Create the request row
      onProgress(0);
      onStatus("Preparing upload...");
      const rowId = await client.create(schema.tableLogicalName, {
        [c.name]: file.name.slice(0, 100),
        [c.targetTable]: target.table,
        [c.targetRecordId]: target.recordId,
        [c.fileName]: file.name,
        [c.fileSize]: file.size,
        [c.contentType]: file.type || "application/octet-stream",
        [c.status]: UploadRequestStatus.Requested
      });
      active.rowId = rowId;
      this.throwIfCancelled(active);

      // 2. Wait for Flow 1 to issue the SAS URL
      const sasRow = await this.waitForRow(
        active,
        rowId,
        [c.status, c.sasUrl, c.errorMessage],
        (row) => {
          const status = row[c.status];
          return (
            (status === UploadRequestStatus.SasIssued && !!row[c.sasUrl]) ||
            status === UploadRequestStatus.Rejected ||
            status === UploadRequestStatus.Failed
          );
        },
        config.sasTimeoutMs,
        "Preparing the upload took too long. Please try again."
      );
      if (sasRow[c.status] !== UploadRequestStatus.SasIssued) {
        throw new Error(sasRow[c.errorMessage] || "The upload request was rejected.");
      }
      const sasUrl = String(sasRow[c.sasUrl]);
      this.assertSasUrlIsOurs(sasUrl);

      // 3. Upload straight to Blob Storage
      onStatus("Uploading...");
      stage = "upload";
      await uploadToSas(
        file,
        sasUrl,
        active.ctl,
        (sent, total) => onProgress(total === 0 ? 100 : Math.min(99, Math.floor((sent / total) * 100))),
        { blockSizeBytes: config.blockSizeBytes }
      );
      this.throwIfCancelled(active);
      stage = "scan";
      onProgress(100);

      // The SAS is a short-lived write capability; remove it from the row (best effort).
      // NOTE: we deliberately do NOT write the status here - Flow 2 owns it, and a scan can
      // finish before this line runs.
      this.markRow(active, { [c.sasUrl]: null });

      // 4. Wait for the scan result
      if (config.waitForScanResult) {
        onStatus("Scanning for viruses...");
        const finalRow = await this.waitForRow(
          active,
          rowId,
          [c.status, c.errorMessage, c.sharePointUrl],
          (row) => {
            const s = row[c.status];
            return (
              s === UploadRequestStatus.Clean ||
              s === UploadRequestStatus.Infected ||
              s === UploadRequestStatus.Failed ||
              s === UploadRequestStatus.Rejected
            );
          },
          config.scanTimeoutMs,
          "The security scan is taking longer than expected. The file stays in quarantine and will be " +
            "added to the record automatically once it is cleared."
        );
        const status = finalRow[c.status];
        if (status === UploadRequestStatus.Infected) {
          throw new Error(
            finalRow[c.errorMessage] || "The file failed the security scan and was rejected."
          );
        }
        if (status !== UploadRequestStatus.Clean) {
          throw new Error(finalRow[c.errorMessage] || "The file could not be processed.");
        }
      }

      onComplete({
        uploadReference: rowId,
        status: "success",
        timestamp: new Date().toISOString()
      });
    } catch (e) {
      if (isCancelledError(e) || active.ctl.cancelled) {
        return; // the UI already shows "Cancelled"
      }
      if (stage !== "scan") {
        this.markRow(active, {
          [c.status]: UploadRequestStatus.Failed,
          [c.errorMessage]: this.messageOf(e).slice(0, 500)
        });
      }
      onError(this.messageOf(e));
    }
  }

  // ------------------------------------------------------------------

  private async waitForRow(
    active: ActiveUpload,
    rowId: string,
    selectColumns: string[],
    isDone: (row: Record<string, any>) => boolean,
    timeoutMs: number,
    timeoutMessage: string
  ): Promise<Record<string, any>> {
    const { config, client } = this.deps;
    const table = getUploadRequestSchema(config).tableLogicalName;
    const started = Date.now();
    let consecutiveErrors = 0;

    for (;;) {
      this.throwIfCancelled(active);
      try {
        const row = await client.retrieve(table, rowId, selectColumns);
        consecutiveErrors = 0;
        if (isDone(row)) return row;
      } catch (e) {
        consecutiveErrors++;
        if (consecutiveErrors >= 3) throw e;
      }
      if (Date.now() - started > timeoutMs) {
        throw new Error(timeoutMessage);
      }
      await new Promise((resolve) => setTimeout(resolve, config.pollIntervalMs));
    }
  }

  /** Best-effort row update that never throws. */
  private markRow(active: ActiveUpload, data: Record<string, unknown>): void {
    if (!active.rowId) return;
    const table = getUploadRequestSchema(this.deps.config).tableLogicalName;
    this.deps.client.update(table, active.rowId, data).catch(() => {
      /* ignore */
    });
  }

  private throwIfCancelled(active: ActiveUpload): void {
    if (active.ctl.cancelled) throw cancelledError();
  }

  /** Never send a file to a URL that is not our own storage account / container. */
  private assertSasUrlIsOurs(sasUrl: string): void {
    const { storageAccountName, containerName } = this.deps.config;
    let url: URL;
    try {
      url = new URL(sasUrl);
    } catch {
      throw new Error("The upload link returned by the flow is not a valid URL.");
    }
    const expectedHost = `${storageAccountName.trim().toLowerCase()}.blob.core.windows.net`;
    const containerPrefix = `/${containerName.trim()}/`;
    if (
      url.protocol !== "https:" ||
      url.hostname.toLowerCase() !== expectedHost ||
      url.pathname.indexOf(containerPrefix) !== 0
    ) {
      throw new Error(
        "The upload link does not point at the configured storage account/container. Check " +
          "storageAccountName / containerName in the control config and in Flow 1."
      );
    }
  }

  private messageOf(e: unknown): string {
    return e instanceof Error && e.message ? e.message : "Upload failed.";
  }
}
