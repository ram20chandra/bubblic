import { IDataverseClient, cleanGuid } from "./IDataverseClient";

/** Gets the anti-forgery token the Power Pages Web API requires on every write. */
function getPortalToken(): Promise<string> {
  const shell = (window as any).shell;
  return new Promise<string>((resolve, reject) => {
    if (!shell || typeof shell.getTokenDeferred !== "function") {
      reject(new Error("Power Pages 'shell' object not found; cannot call the portal Web API."));
      return;
    }
    shell.getTokenDeferred().done(resolve).fail(() => reject(new Error("Could not get the Power Pages request token.")));
  });
}

/**
 * Power Pages: calls the portal Web API (/_api/<entity set>) as the signed-in portal user.
 * Requires, for the Upload Request table: site settings Webapi/<table>/enabled and
 * Webapi/<table>/fields, plus table permissions (Create, Read, Write) - see docs.
 */
export class PortalDataverseClient implements IDataverseClient {
  constructor(
    private entitySetName: string,
    private baseUrl: string = window.location.origin,
    private tokenProvider: () => Promise<string> = getPortalToken,
    private fetchFn: typeof fetch = (input, init) => window.fetch(input, init)
  ) {}

  private url(path: string): string {
    return `${this.baseUrl}/_api/${this.entitySetName}${path}`;
  }

  private async headers(): Promise<Record<string, string>> {
    const token = await this.tokenProvider();
    return {
      "Content-Type": "application/json",
      Accept: "application/json",
      "OData-MaxVersion": "4.0",
      "OData-Version": "4.0",
      __RequestVerificationToken: token
    };
  }

  private async fail(response: Response, action: string): Promise<never> {
    let detail = "";
    try {
      const body = await response.json();
      detail = body && body.error && body.error.message ? `: ${body.error.message}` : "";
    } catch {
      /* ignore */
    }
    throw new Error(`Power Pages Web API ${action} failed (${response.status})${detail}`);
  }

  async create(_tableLogicalName: string, data: Record<string, unknown>): Promise<string> {
    const response = await this.fetchFn(this.url(""), {
      method: "POST",
      headers: await this.headers(),
      credentials: "same-origin",
      body: JSON.stringify(data)
    });
    if (!response.ok) return this.fail(response, "create");
    const id = response.headers.get("entityid");
    if (!id) {
      throw new Error("Power Pages Web API did not return the new row id (entityid header).");
    }
    return cleanGuid(id);
  }

  async retrieve(
    _tableLogicalName: string,
    id: string,
    selectColumns: string[]
  ): Promise<Record<string, any>> {
    const response = await this.fetchFn(this.url(`(${id})?$select=${selectColumns.join(",")}`), {
      method: "GET",
      headers: await this.headers(),
      credentials: "same-origin"
    });
    if (!response.ok) return this.fail(response, "read");
    return response.json();
  }

  async update(_tableLogicalName: string, id: string, data: Record<string, unknown>): Promise<void> {
    const response = await this.fetchFn(this.url(`(${id})`), {
      method: "PATCH",
      headers: await this.headers(),
      credentials: "same-origin",
      body: JSON.stringify(data)
    });
    if (!response.ok) return this.fail(response, "update");
  }
}
