/**
 * Minimal Dataverse access used by the upload service. Two implementations:
 *  - PcfDataverseClient     (model-driven / D365: context.webAPI)
 *  - PortalDataverseClient  (Power Pages: portal Web API at /_api)
 */
export interface IDataverseClient {
  /** Creates a row and returns its id (GUID without braces). */
  create(tableLogicalName: string, data: Record<string, unknown>): Promise<string>;

  /** Reads selected columns of one row. Column names are logical names. */
  retrieve(
    tableLogicalName: string,
    id: string,
    selectColumns: string[]
  ): Promise<Record<string, any>>;

  /** Updates columns of one row. */
  update(tableLogicalName: string, id: string, data: Record<string, unknown>): Promise<void>;
}

export function cleanGuid(id: string): string {
  return (id || "").replace(/[{}]/g, "").toLowerCase();
}
