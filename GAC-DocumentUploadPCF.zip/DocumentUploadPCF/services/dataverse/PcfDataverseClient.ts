import { IDataverseClient, cleanGuid } from "./IDataverseClient";

/** The subset of ComponentFramework.WebApi this client needs (structurally compatible). */
export interface IPcfWebApi {
  createRecord(entityType: string, data: any): Promise<{ id: string }>;
  retrieveRecord(entityType: string, id: string, options?: string): Promise<any>;
  updateRecord(entityType: string, id: string, data: any): Promise<any>;
}

/** Model-driven apps (D365): runs as the signed-in user through context.webAPI. */
export class PcfDataverseClient implements IDataverseClient {
  constructor(private webApi: IPcfWebApi | undefined) {}

  private get api(): IPcfWebApi {
    if (!this.webApi) {
      throw new Error("context.webAPI is not available in this host, so the upload request cannot be created.");
    }
    return this.webApi;
  }

  async create(tableLogicalName: string, data: Record<string, unknown>): Promise<string> {
    const result = await this.api.createRecord(tableLogicalName, data);
    return cleanGuid(result.id);
  }

  async retrieve(
    tableLogicalName: string,
    id: string,
    selectColumns: string[]
  ): Promise<Record<string, any>> {
    return this.api.retrieveRecord(tableLogicalName, id, `?$select=${selectColumns.join(",")}`);
  }

  async update(tableLogicalName: string, id: string, data: Record<string, unknown>): Promise<void> {
    await this.api.updateRecord(tableLogicalName, id, data);
  }
}
