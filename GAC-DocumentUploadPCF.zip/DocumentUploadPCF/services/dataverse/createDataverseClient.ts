import { IAzureUploadConfig, getUploadRequestSchema } from "../../config/AzureUploadConfig";
import { IDataverseClient } from "./IDataverseClient";
import { PcfDataverseClient, IPcfWebApi } from "./PcfDataverseClient";
import { PortalDataverseClient } from "./PortalDataverseClient";

/** True when running inside a Power Pages site (the portal `shell` helper exists). */
export function isPowerPages(): boolean {
  const shell = (window as any).shell;
  return !!shell && typeof shell.getTokenDeferred === "function";
}

export function createDataverseClient(
  webApi: IPcfWebApi | undefined,
  cfg: IAzureUploadConfig
): IDataverseClient {
  const mode = cfg.hostMode === "auto" ? (isPowerPages() ? "powerPages" : "modelDriven") : cfg.hostMode;

  if (mode === "powerPages") {
    return new PortalDataverseClient(getUploadRequestSchema(cfg).entitySetName);
  }
  // If webApi is missing the client throws a clear error when first used (not at control load).
  return new PcfDataverseClient(webApi);
}
