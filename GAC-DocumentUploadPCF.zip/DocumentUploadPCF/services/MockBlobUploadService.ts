import { IUploadService, UploadResult } from "./IUploadService";
import { UploadStatus } from "../models/UploadMetadata";

interface ActiveUpload {
  file: File;
  intervalId: number;
  progress: number;
  cancelled: boolean;
  onProgress: (progress: number) => void;
  onComplete: (result: UploadResult) => void;
  onError: (error: string) => void;
}

/**
 * Mock implementation that simulates network upload progress without real requests.
 * Useful for development, unit tests, and demos.
 * Replace with AzureBlobUploadService for production.
 */
export class MockBlobUploadService implements IUploadService {
  private uploads: Map<string, ActiveUpload> = new Map();
  private nextId = 1;

  /** Probability of simulated failure (0-1). Set to 0 for always-success. */
  public failureRate = 0.15;

  /** Simulated upload duration in ms (roughly). */
  public simulatedDurationMs = 2500;

  upload(
    file: File,
    onProgress: (progress: number) => void,
    onComplete: (result: UploadResult) => void,
    onError: (error: string) => void
  ): string {
    const uploadId = `mock-upload-${this.nextId++}-${Date.now()}`;
    this.startSimulation(uploadId, file, onProgress, onComplete, onError);
    return uploadId;
  }

  cancel(uploadId: string): void {
    const active = this.uploads.get(uploadId);
    if (active) {
      active.cancelled = true;
      if (active.intervalId) {
        clearInterval(active.intervalId);
      }
      this.uploads.delete(uploadId);
    }
  }

  retry(
    file: File,
    previousUploadId: string,
    onProgress: (progress: number) => void,
    onComplete: (result: UploadResult) => void,
    onError: (error: string) => void
  ): string {
    // Clean up any residual state
    this.cancel(previousUploadId);
    return this.upload(file, onProgress, onComplete, onError);
  }

  private startSimulation(
    uploadId: string,
    file: File,
    onProgress: (progress: number) => void,
    onComplete: (result: UploadResult) => void,
    onError: (error: string) => void
  ): void {
    const steps = 20;
    const stepMs = Math.max(50, Math.floor(this.simulatedDurationMs / steps));
    let progress = 0;

    const active: ActiveUpload = {
      file,
      intervalId: 0,
      progress: 0,
      cancelled: false,
      onProgress,
      onComplete,
      onError
    };

    active.intervalId = window.setInterval(() => {
      if (active.cancelled) {
        clearInterval(active.intervalId);
        this.uploads.delete(uploadId);
        return;
      }

      progress += 100 / steps;
      if (progress >= 100) {
        progress = 100;
        clearInterval(active.intervalId);
        this.uploads.delete(uploadId);

        // Simulate occasional failure
        if (Math.random() < this.failureRate) {
          onError("Simulated upload failure. Please retry.");
          return;
        }

        const result: UploadResult = {
          uploadReference: `mock-ref-${uploadId}`,
          status: "success" as UploadStatus,
          timestamp: new Date().toISOString()
        };
        onComplete(result);
        return;
      }

      active.progress = progress;
      onProgress(Math.floor(progress));
    }, stepMs) as unknown as number;

    this.uploads.set(uploadId, active);
    // Immediate first progress tick
    onProgress(0);
  }
}
