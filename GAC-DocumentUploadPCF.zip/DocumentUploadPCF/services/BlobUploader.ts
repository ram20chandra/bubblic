/**
 * Uploads a File to Azure Blob Storage through a short-lived SAS URL, straight from the browser.
 *  - small files: a single "Put Blob"
 *  - larger files: "Put Block" per chunk, then "Put Block List" to commit
 * Uses XMLHttpRequest because fetch() cannot report upload progress.
 *
 * The SAS must allow Create + Write. The storage account needs a CORS rule that allows the
 * D365 / Power Pages origin with methods PUT and OPTIONS (see docs/AZURE-UPLOAD-SETUP.md).
 */

export interface UploadControl {
  cancelled: boolean;
  aborters: Set<() => void>;
}

export function newUploadControl(): UploadControl {
  return { cancelled: false, aborters: new Set<() => void>() };
}

export function cancelControl(ctl: UploadControl): void {
  ctl.cancelled = true;
  ctl.aborters.forEach((abort) => abort());
  ctl.aborters.clear();
}

const CANCELLED_NAME = "UploadCancelled";

export function cancelledError(): Error {
  const e = new Error("Upload cancelled.");
  e.name = CANCELLED_NAME;
  return e;
}

export function isCancelledError(e: unknown): boolean {
  return !!e && (e as Error).name === CANCELLED_NAME;
}

interface RetryableError extends Error {
  retryable?: boolean;
}

function transportError(message: string, retryable: boolean): RetryableError {
  const e: RetryableError = new Error(message);
  e.retryable = retryable;
  return e;
}

function httpError(xhr: XMLHttpRequest): RetryableError {
  const code = /<Code>([^<]+)<\/Code>/.exec(xhr.responseText || "");
  const azureCode = code ? code[1] : "";
  let message: string;
  if (xhr.status === 403) {
    message =
      "Azure rejected the upload link (403" +
      (azureCode ? ` ${azureCode}` : "") +
      "). The link may have expired or does not allow writing.";
  } else if (xhr.status === 404) {
    message = "Azure could not find the upload container (404). Check the container name.";
  } else {
    message = `Upload to Azure failed (HTTP ${xhr.status}${azureCode ? ` ${azureCode}` : ""}).`;
  }
  return transportError(message, xhr.status >= 500 || xhr.status === 429);
}

function xhrPut(
  url: string,
  body: Blob | string,
  headers: Record<string, string>,
  ctl: UploadControl,
  onProgress?: (loaded: number) => void
): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    if (ctl.cancelled) {
      reject(cancelledError());
      return;
    }
    const xhr = new XMLHttpRequest();
    const abort = () => xhr.abort();
    ctl.aborters.add(abort);
    const finish = () => ctl.aborters.delete(abort);

    xhr.open("PUT", url, true);
    xhr.timeout = 5 * 60 * 1000;
    Object.keys(headers).forEach((k) => xhr.setRequestHeader(k, headers[k]));

    xhr.upload.onprogress = (e) => {
      if (onProgress && e.lengthComputable) onProgress(e.loaded);
    };
    xhr.onload = () => {
      finish();
      if (xhr.status >= 200 && xhr.status < 300) resolve();
      else reject(httpError(xhr));
    };
    xhr.onerror = () => {
      finish();
      reject(
        transportError(
          "Could not reach Azure Storage. Check the network and that the storage account allows this site (CORS).",
          true
        )
      );
    };
    xhr.ontimeout = () => {
      finish();
      reject(transportError("The upload to Azure timed out.", true));
    };
    xhr.onabort = () => {
      finish();
      reject(ctl.cancelled ? cancelledError() : transportError("The upload was interrupted.", true));
    };
    xhr.send(body);
  });
}

async function withRetry<T>(fn: () => Promise<T>, ctl: UploadControl, attempts = 3): Promise<T> {
  let lastError: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (e) {
      lastError = e;
      if (isCancelledError(e) || ctl.cancelled) throw e;
      if (!(e as RetryableError).retryable || i === attempts - 1) throw e;
      await new Promise((r) => setTimeout(r, 500 * (i + 1)));
    }
  }
  throw lastError;
}

function withParams(sasUrl: string, params: string): string {
  return sasUrl + (sasUrl.indexOf("?") === -1 ? "?" : "&") + params;
}

function blockId(index: number): string {
  // All block ids in a blob must have the same length before base64 encoding.
  return btoa(("00000000" + index).slice(-8));
}

function blockListXml(ids: string[]): string {
  return (
    '<?xml version="1.0" encoding="utf-8"?><BlockList>' +
    ids.map((id) => `<Latest>${id}</Latest>`).join("") +
    "</BlockList>"
  );
}

export interface BlobUploadOptions {
  blockSizeBytes: number;
}

export async function uploadToSas(
  file: File,
  sasUrl: string,
  ctl: UploadControl,
  onProgress: (bytesSent: number, totalBytes: number) => void,
  options: BlobUploadOptions
): Promise<void> {
  const total = file.size;
  const contentType = file.type || "application/octet-stream";

  if (total <= options.blockSizeBytes) {
    await withRetry(
      () =>
        xhrPut(
          sasUrl,
          file,
          {
            "x-ms-blob-type": "BlockBlob",
            "x-ms-blob-content-type": contentType,
            "Content-Type": contentType
          },
          ctl,
          (loaded) => onProgress(loaded, total)
        ),
      ctl
    );
    onProgress(total, total);
    return;
  }

  const ids: string[] = [];
  let sentBefore = 0;
  for (let offset = 0, i = 0; offset < total; offset += options.blockSizeBytes, i++) {
    const end = Math.min(offset + options.blockSizeBytes, total);
    const chunk = file.slice(offset, end);
    const id = blockId(i);
    ids.push(id);
    const base = sentBefore;
    await withRetry(
      () =>
        xhrPut(
          withParams(sasUrl, `comp=block&blockid=${encodeURIComponent(id)}`),
          chunk,
          { "Content-Type": "application/octet-stream" },
          ctl,
          (loaded) => onProgress(base + loaded, total)
        ),
      ctl
    );
    sentBefore += end - offset;
    onProgress(sentBefore, total);
  }

  await withRetry(
    () =>
      xhrPut(
        withParams(sasUrl, "comp=blocklist"),
        blockListXml(ids),
        { "Content-Type": "application/xml", "x-ms-blob-content-type": contentType },
        ctl
      ),
    ctl
  );
}
