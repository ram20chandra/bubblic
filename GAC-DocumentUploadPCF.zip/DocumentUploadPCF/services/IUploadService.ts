import { IFileUploadMetadata, UploadStatus } from "../models/UploadMetadata";

/**
 * Abstraction for the upload service.
 * UI and validation depend only on this interface.
 * Replace MockBlobUploadService with AzureBlobUploadService later without changing UI.
 */
export interface IUploadService {
  /**
   * Starts an upload for the given file.
   * Returns a unique upload reference and reports progress via callback.
   */
  upload(
    file: File,
    onProgress: (progress: number) => void,
    onComplete: (result: UploadResult) => void,
    onError: (error: string) => void,
    /** Optional: short phase text for the UI, e.g. "Scanning for viruses...". */
    onStatus?: (text: string) => void
  ): string; // returns uploadId that can be used for cancel/retry

  /**
   * Cancels an in-progress upload.
   */
  cancel(uploadId: string): void;

  /**
   * Retries a previously failed upload.
   * Returns a new uploadId.
   */
  retry(
    file: File,
    previousUploadId: string,
    onProgress: (progress: number) => void,
    onComplete: (result: UploadResult) => void,
    onError: (error: string) => void,
    onStatus?: (text: string) => void
  ): string;
}

export interface UploadResult {
  uploadReference: string;
  status: UploadStatus;
  timestamp: string;
}

/**
 * Future AzureBlobUploadService will implement the same interface and call
 * an authenticated short-lived SAS / upload API endpoint. Never embed secrets.
 */
