import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { FileUploader } from "./components/FileUploader";
import { MockBlobUploadService } from "./services/MockBlobUploadService";
import { AzureBlobUploadService, ITargetRecord } from "./services/AzureBlobUploadService";
import { createDataverseClient } from "./services/dataverse/createDataverseClient";
import { IUploadService } from "./services/IUploadService";
import { UploadConfig } from "./config/UploadConfig";
import { AzureUploadConfig } from "./config/AzureUploadConfig";

const GUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * DocumentUpload PCF Control
 * Standard (non-React) control for document upload (single file by default, several with the
 * "Allow multiple files (Y/N)" parameter) with validation. Uploads go to Azure Blob Storage via
 * AzureBlobUploadService, or are simulated by MockBlobUploadService (config/AzureUploadConfig.ts).
 * Markup is WET / GCWeb compatible.
 */
export class DocumentUpload implements ComponentFramework.StandardControl<IInputs, IOutputs> {
  private container!: HTMLDivElement;
  private notifyOutputChanged!: () => void;
  private context!: ComponentFramework.Context<IInputs>;
  private uploader: FileUploader | null = null;
  private currentMetadataJson: string = "[]";
  private uploadService!: IUploadService;

  /**
   * Empty constructor.
   */
  constructor() {
    // The upload service needs the PCF context, so it is created in init().
  }

  /**
   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
   * Data-set values are not initialized here, use updateView.
   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
   */
  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    state: ComponentFramework.Dictionary,
    container: HTMLDivElement
  ): void {
    this.container = container;
    this.notifyOutputChanged = notifyOutputChanged;
    this.context = context;

    // Seed from existing bound value if present
    if (context.parameters.uploadMetadata.raw) {
      this.currentMetadataJson = context.parameters.uploadMetadata.raw;
    }

    this.uploadService = this.createUploadService();

    this.uploader = new FileUploader(
      this.container,
      this.uploadService,
      (json: string) => {
        this.currentMetadataJson = json;
        this.notifyOutputChanged();
      },
      // "Allow multiple files (Y/N)" control parameter (set per form, default N); falls back to
      // config/UploadConfig.ts when the parameter is not provided.
      { allowMultiple: this.resolveAllowMultiple(context), testMode: AzureUploadConfig.useMockService }
    );
  }

  /**
   * "Allow multiple files (Y/N)" parameter: Y / YES / TRUE / 1 -> multiple files;
   * N, blank, or anything else -> single file (default).
   */
  private resolveAllowMultiple(context: ComponentFramework.Context<IInputs>): boolean {
    const param = context.parameters.allowMultiple;
    const raw = param && param.raw ? param.raw.trim().toLowerCase() : "";
    if (raw === "") {
      return UploadConfig.allowMultiple; // parameter not set -> fallback (false)
    }
    return raw === "y" || raw === "yes" || raw === "true" || raw === "1";
  }

  /** Real Azure/Dataverse upload, or the simulator when AzureUploadConfig.useMockService is true. */
  private createUploadService(): IUploadService {
    if (AzureUploadConfig.useMockService) {
      return new MockBlobUploadService();
    }
    return new AzureBlobUploadService({
      config: AzureUploadConfig,
      client: createDataverseClient(this.context.webAPI, AzureUploadConfig),
      resolveTarget: () => this.resolveTarget()
    });
  }

  /**
   * Which record the uploaded files belong to.
   *  - D365 form: the record open on the form (context.mode.contextInfo).
   *  - Power Pages: the record id from the page URL (?id=...) and the table from the
   *    "Target table (Power Pages)" parameter.
   * Returns null when the record has not been saved yet.
   */
  private resolveTarget(): ITargetRecord | null {
    const info = ((this.context.mode as any) || {}).contextInfo || {};
    let table: string = info.entityTypeName || "";
    let recordId: string = info.entityId || "";

    if (!table) {
      const param = this.context.parameters.targetTableLogicalName;
      table = param && param.raw ? param.raw.trim().toLowerCase() : "";
    }
    if (!recordId) {
      recordId = new URLSearchParams(window.location.search).get(AzureUploadConfig.recordIdQueryParam) || "";
    }
    recordId = recordId.replace(/[{}]/g, "").trim().toLowerCase();

    if (!table || !GUID_PATTERN.test(recordId)) {
      return null;
    }
    return { table, recordId };
  }

  /**
   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
   */
  public updateView(context: ComponentFramework.Context<IInputs>): void {
    // Keep the latest context: after the user saves a new record, contextInfo gains the record id.
    this.context = context;
    // The control is self-contained; we only push metadata outward.
    // If the bound field is cleared externally we could reset, but for
    // upload UX we keep the UI state independent after init.
  }

  /**
   * It is called by the framework prior to a control receiving new data.
   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”
   */
  public getOutputs(): IOutputs {
    return {
      uploadMetadata: this.currentMetadataJson
    };
  }

  /**
   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
   * i.e. cancelling any pending remote calls, removing listeners, etc.
   */
  public destroy(): void {
    if (this.uploader) {
      this.uploader.destroy();
      this.uploader = null;
    }
  }
}
