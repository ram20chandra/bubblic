<#
 OPTIONAL helper: creates the "Upload Request" table and its columns in Dataverse using the Web API.
 (You can also create them by hand - see docs\AZURE-UPLOAD-SETUP.md section 2. This script has not been
 run against a live environment by its author; if anything errors, create the table manually.)

 Needs the Azure CLI signed in to the same tenant:  az login
 Usage:  .\scripts\Create-UploadRequestTable.ps1 -OrgUrl https://YOURORG.crm.dynamics.com -SolutionUniqueName YourSolution

 -SolutionUniqueName is the UNIQUE NAME of an (unmanaged) solution whose publisher prefix is "gac".
 Create the publisher "GAC" (prefix gac) and a solution first in make.powerapps.com.
#>
param(
  [Parameter(Mandatory = $true)][string]$OrgUrl,
  [Parameter(Mandatory = $true)][string]$SolutionUniqueName,
  [string]$Prefix = "gac"
)

$ErrorActionPreference = "Stop"
$OrgUrl = $OrgUrl.TrimEnd("/")
if (-not (Get-Command az -ErrorAction SilentlyContinue)) { throw "Azure CLI ('az') not found. Install it and run 'az login'." }

$token = az account get-access-token --resource $OrgUrl --query accessToken -o tsv
if (-not $token) { throw "Could not get a token for $OrgUrl. Run 'az login' with an account that has access to the environment." }

$headers = @{
  Authorization              = "Bearer $token"
  "OData-MaxVersion"         = "4.0"
  "OData-Version"            = "4.0"
  Accept                     = "application/json"
  "Content-Type"             = "application/json; charset=utf-8"
  "MSCRM.SolutionUniqueName" = $SolutionUniqueName
}
$api = "$OrgUrl/api/data/v9.2"
$table = "${Prefix}_uploadrequest"

function Label([string]$Text) {
  @{ "@odata.type" = "Microsoft.Dynamics.CRM.Label"
     LocalizedLabels = @(@{ "@odata.type" = "Microsoft.Dynamics.CRM.LocalizedLabel"; Label = $Text; LanguageCode = 1033 }) }
}
function Required([string]$Level) {
  @{ Value = $Level; CanBeChanged = $true; ManagedPropertyLogicalName = "canmodifyrequirementlevelsettings" }
}
function Exists([string]$Url) {
  try { Invoke-RestMethod -Method Get -Uri $Url -Headers $headers | Out-Null; return $true }
  catch { if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 404) { return $false } else { throw } }
}
function Post([string]$Url, $Body) {
  Invoke-RestMethod -Method Post -Uri $Url -Headers $headers -Body ($Body | ConvertTo-Json -Depth 20) | Out-Null
}

function StringCol([string]$Name, [string]$Display, [int]$Max, [string]$Format = "Text", [bool]$Primary = $false) {
  $col = @{
    "@odata.type" = "Microsoft.Dynamics.CRM.StringAttributeMetadata"
    SchemaName    = "${Prefix}_$Name"
    DisplayName   = (Label $Display)
    Description   = (Label $Display)
    RequiredLevel = (Required "None")
    MaxLength     = $Max
    FormatName    = @{ Value = $Format }
  }
  if ($Primary) { $col["IsPrimaryName"] = $true }
  return $col
}
function MemoCol([string]$Name, [string]$Display, [int]$Max) {
  @{ "@odata.type" = "Microsoft.Dynamics.CRM.MemoAttributeMetadata"
     SchemaName = "${Prefix}_$Name"; DisplayName = (Label $Display); Description = (Label $Display)
     RequiredLevel = (Required "None"); MaxLength = $Max; Format = "TextArea" }
}
function WholeCol([string]$Name, [string]$Display) {
  @{ "@odata.type" = "Microsoft.Dynamics.CRM.IntegerAttributeMetadata"
     SchemaName = "${Prefix}_$Name"; DisplayName = (Label $Display); Description = (Label $Display)
     RequiredLevel = (Required "None"); Format = "None"; MinValue = 0; MaxValue = 2147483647 }
}

# 1. Table (with its primary name column)
if (Exists "$api/EntityDefinitions(LogicalName='$table')?`$select=LogicalName") {
  Write-Host "Table $table already exists - adding any missing columns." -ForegroundColor Yellow
} else {
  Write-Host "Creating table $table..." -ForegroundColor Cyan
  Post "$api/EntityDefinitions" @{
    "@odata.type"         = "Microsoft.Dynamics.CRM.EntityMetadata"
    SchemaName            = "${Prefix}_UploadRequest"
    DisplayName           = (Label "Upload Request")
    DisplayCollectionName = (Label "Upload Requests")
    Description           = (Label "One row per file uploaded by the Document Upload control (metadata only, never the file).")
    OwnershipType         = "UserOwned"
    HasActivities         = $false
    HasNotes              = $false
    Attributes            = @( (StringCol "name" "Name" 100 "Text" $true) )
  }
}

# 2. Columns
$columns = @(
  (StringCol "targettable"   "Target table"     100),
  (StringCol "targetrecordid" "Target record id" 40),
  (StringCol "filename"      "File name"        400),
  (WholeCol  "filesize"      "File size (bytes)"),
  (StringCol "contenttype"   "Content type"     200),
  (StringCol "status"        "Status"           50),
  (MemoCol   "sasurl"        "SAS URL"          4000),
  (StringCol "blobname"      "Blob name"        500),
  (MemoCol   "errormessage"  "Error message"    1000),
  (StringCol "sharepointurl" "SharePoint URL"   2000 "Url")
)
foreach ($col in $columns) {
  $logical = $col.SchemaName.ToLower()
  if (Exists "$api/EntityDefinitions(LogicalName='$table')/Attributes(LogicalName='$logical')?`$select=LogicalName") {
    Write-Host "  $logical exists - skipped"
  } else {
    Write-Host "  adding $logical"
    Post "$api/EntityDefinitions(LogicalName='$table')/Attributes" $col
  }
}

# 3. Publish
Write-Host "Publishing customizations..." -ForegroundColor Cyan
Invoke-RestMethod -Method Post -Uri "$api/PublishAllXml" -Headers $headers -Body "{}" | Out-Null

Write-Host ""
Write-Host "Done. Table: $table  (collection: ${Prefix}_uploadrequests)" -ForegroundColor Green
Write-Host "Still to do by hand: security role (Create/Read/Write on Upload Request) and, for Power Pages, site settings + table permission. See docs\AZURE-UPLOAD-SETUP.md."
