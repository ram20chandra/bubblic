<#
 Quick dev import of the control into a Dataverse environment.
 Usage:  .\scripts\Push.ps1 -EnvironmentUrl https://YOURORG.crm.dynamics.com

 Signs you in (a browser window opens), shows which environment you are connected to, then runs
 `pac pcf push` with the publisher prefix gac. Run .\scripts\Build.ps1 first.
#>
param(
  [Parameter(Mandatory = $true)][string]$EnvironmentUrl,
  [string]$PublisherPrefix = "gac",
  [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = "Stop"

function Invoke-Native([scriptblock]$Command, [string]$What) {
  & $Command
  if ($LASTEXITCODE -ne 0) { throw "$What failed (exit code $LASTEXITCODE). See the messages above." }
}

if (-not (Get-Command pac -ErrorAction SilentlyContinue)) { throw "'pac' not found. Install the Power Platform CLI first." }
Set-Location $ProjectRoot
if (-not (Get-ChildItem -Filter *.pcfproj)) { throw "No .pcfproj found. Run .\scripts\Build.ps1 first." }

Invoke-Native { pac auth create --url $EnvironmentUrl } "pac auth create"
Write-Host "Connected to:" -ForegroundColor Cyan
Invoke-Native { pac org who } "pac org who"

Write-Host "Pushing the control (publisher prefix '$PublisherPrefix')..." -ForegroundColor Cyan
Invoke-Native { pac pcf push --publisher-prefix $PublisherPrefix } "pac pcf push"

Write-Host ""
Write-Host "Pushed. Control name in Dataverse: ${PublisherPrefix}_GAC.DocumentUpload" -ForegroundColor Green
Write-Host "Now add it to a form (see INSTALL.md, step 4)."
