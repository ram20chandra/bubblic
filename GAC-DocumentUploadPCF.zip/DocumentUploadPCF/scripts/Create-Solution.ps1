<#
 Builds an importable Dataverse solution .zip containing the control, with publisher GAC / prefix gac.
 Usage:  .\scripts\Create-Solution.ps1            (unmanaged .zip - for dev/test environments)
         .\scripts\Create-Solution.ps1 -Managed   (managed .zip  - for UAT / production)
 Requires the .NET SDK 6 or later. Run .\scripts\Build.ps1 first.

 The .zip is created in  ..\GACDocumentUploadSolution\bin\Debug  (or \bin\Release when -Managed).
 Import it at make.powerapps.com -> Solutions -> Import solution.
#>
param(
  [string]$PublisherName = "GAC",
  [string]$PublisherPrefix = "gac",
  [switch]$Managed,
  [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = "Stop"

function Invoke-Native([scriptblock]$Command, [string]$What) {
  & $Command
  if ($LASTEXITCODE -ne 0) { throw "$What failed (exit code $LASTEXITCODE). See the messages above." }
}

foreach ($c in @("pac", "dotnet")) {
  if (-not (Get-Command $c -ErrorAction SilentlyContinue)) { throw "'$c' not found. Install the Power Platform CLI and the .NET SDK 6+." }
}
if (-not (Get-ChildItem -Path $ProjectRoot -Filter *.pcfproj)) { throw "No .pcfproj found. Run .\scripts\Build.ps1 first." }

$solutionFolder = Join-Path (Split-Path -Parent $ProjectRoot) "GACDocumentUploadSolution"
New-Item -ItemType Directory -Path $solutionFolder -Force | Out-Null
Set-Location $solutionFolder

if (-not (Get-ChildItem -Filter *.cdsproj -ErrorAction SilentlyContinue)) {
  Invoke-Native { pac solution init --publisher-name $PublisherName --publisher-prefix $PublisherPrefix } "pac solution init"
  Invoke-Native { pac solution add-reference --path $ProjectRoot } "pac solution add-reference"
}

$config = if ($Managed) { "Release" } else { "Debug" }
Invoke-Native { dotnet build --configuration $config } "dotnet build"

$zip = Get-ChildItem -Path (Join-Path $solutionFolder "bin\$config") -Filter *.zip -ErrorAction SilentlyContinue | Select-Object -First 1
Write-Host ""
if ($zip) { Write-Host "Solution package: $($zip.FullName)" -ForegroundColor Green }
else      { Write-Host "Build finished - look for the .zip under $solutionFolder\bin\$config" -ForegroundColor Yellow }
