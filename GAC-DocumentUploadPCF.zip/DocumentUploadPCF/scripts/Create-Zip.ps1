# Creates DocumentUploadPCF.zip from the project root (parent of scripts/)
# Usage: .\scripts\Create-Zip.ps1

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$zipPath = Join-Path (Split-Path -Parent $projectRoot) "DocumentUploadPCF.zip"

if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

# Exclude node_modules, out, coverage, .git
$exclude = @(
    "node_modules",
    "out",
    "coverage",
    ".git",
    "*.zip"
)

$tempDir = Join-Path $env:TEMP "DocumentUploadPCF-pack"
if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }
New-Item -ItemType Directory -Path $tempDir | Out-Null

Get-ChildItem -Path $projectRoot -Force | Where-Object {
    $name = $_.Name
    -not ($exclude | Where-Object { $name -like $_ })
} | ForEach-Object {
    Copy-Item $_.FullName -Destination $tempDir -Recurse -Force
}

Compress-Archive -Path (Join-Path $tempDir "*") -DestinationPath $zipPath -Force
Remove-Item $tempDir -Recurse -Force

Write-Host "Created: $zipPath"
