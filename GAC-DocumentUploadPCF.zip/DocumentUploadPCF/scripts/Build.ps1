<#
 Builds the control locally. Run from anywhere:  .\scripts\Build.ps1

 - Generates the .pcfproj file the Power Platform CLI needs (this zip does not ship one, so it is
   always created by YOUR version of `pac` - the supported way).
 - npm install, then npm run build (the real PCF build).
#>
param(
  [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = "Stop"

function Invoke-Native([scriptblock]$Command, [string]$What) {
  & $Command
  if ($LASTEXITCODE -ne 0) { throw "$What failed (exit code $LASTEXITCODE). See the messages above." }
}
function Require-Command([string]$Name, [string]$Hint) {
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) { throw "'$Name' was not found. $Hint" }
}

Require-Command node "Install Node.js LTS from https://nodejs.org"
Require-Command npm  "Install Node.js LTS from https://nodejs.org"
Require-Command pac  "Install the Power Platform CLI: 'dotnet tool install --global Microsoft.PowerApps.CLI.Tool' (or the VS Code 'Power Platform Tools' extension)."

Set-Location $ProjectRoot
Write-Host "Project: $ProjectRoot" -ForegroundColor Cyan

# 1. .pcfproj
$existing = Get-ChildItem -Path $ProjectRoot -Filter *.pcfproj -ErrorAction SilentlyContinue | Select-Object -First 1
if ($existing) {
  Write-Host "Found $($existing.Name) - keeping it." -ForegroundColor Green
} else {
  Write-Host "Generating .pcfproj with 'pac pcf init'..." -ForegroundColor Cyan
  $scratchParent = Join-Path ([IO.Path]::GetTempPath()) ("pcf-scaffold-" + [guid]::NewGuid().ToString("N"))
  $scratch = Join-Path $scratchParent (Split-Path -Leaf $ProjectRoot)
  New-Item -ItemType Directory -Path $scratch -Force | Out-Null
  Push-Location $scratch
  try {
    Invoke-Native { pac pcf init --namespace GAC --name DocumentUpload --template field } "pac pcf init"
  } finally { Pop-Location }
  $generated = Get-ChildItem -Path $scratch -Filter *.pcfproj | Select-Object -First 1
  if (-not $generated) { throw "pac pcf init did not produce a .pcfproj file." }
  Copy-Item $generated.FullName (Join-Path $ProjectRoot $generated.Name)
  Remove-Item $scratchParent -Recurse -Force
  Write-Host "Created $($generated.Name)" -ForegroundColor Green
}

# 2. npm install + build
Invoke-Native { npm install } "npm install"
Invoke-Native { npm run build } "npm run build"

Write-Host ""
Write-Host "Build succeeded." -ForegroundColor Green
Write-Host "Next:  .\scripts\Push.ps1 -EnvironmentUrl https://YOURORG.crm.dynamics.com   (quick dev import)"
Write-Host "  or:  .\scripts\Create-Solution.ps1                                         (solution .zip to import)"
