import { FileUploader } from "../components/FileUploader";
import { IUploadService, UploadResult } from "../services/IUploadService";

/** Completes every upload asynchronously and successfully. */
class InstantUploadService implements IUploadService {
  upload(
    _file: File,
    onProgress: (p: number) => void,
    onComplete: (r: UploadResult) => void
  ): string {
    onProgress(0);
    setTimeout(
      () =>
        onComplete({
          uploadReference: "ref",
          status: "success",
          timestamp: new Date().toISOString()
        }),
      0
    );
    return "upload-id";
  }
  cancel(): void {}
  retry(
    file: File,
    _prev: string,
    onProgress: (p: number) => void,
    onComplete: (r: UploadResult) => void
  ): string {
    return this.upload(file, onProgress, onComplete);
  }
}

function pdf(name: string): File {
  const bytes = new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x34, 0x0a]); // %PDF-1.4
  return new File([bytes], name, { type: "application/pdf" });
}

function drop(host: HTMLElement, files: File[]): void {
  const zone = host.querySelector(".du-dropzone") as HTMLElement;
  const ev = new Event("drop", { bubbles: true, cancelable: true });
  Object.defineProperty(ev, "dataTransfer", { value: { files } });
  zone.dispatchEvent(ev);
}

const flush = () => new Promise((resolve) => setTimeout(resolve, 60));

describe("FileUploader", () => {
  let host: HTMLDivElement;
  let uploader: FileUploader | null;

  const create = (allowMultiple: boolean) => {
    uploader = new FileUploader(host, new InstantUploadService(), () => {}, { allowMultiple });
  };

  beforeEach(() => {
    host = document.createElement("div");
    document.body.appendChild(host);
    uploader = null;
  });

  afterEach(() => {
    if (uploader) uploader.destroy();
    host.remove();
  });

  test("multi mode: file input allows multiple and several dropped files are all uploaded", async () => {
    create(true);
    expect((host.querySelector("input[type=file]") as HTMLInputElement).multiple).toBe(true);

    drop(host, [pdf("a.pdf"), pdf("b.pdf")]);
    await flush();

    expect(host.querySelectorAll(".du-file-item").length).toBe(2);
    expect(host.querySelector(".du-status-text")!.textContent).toBe(
      "All 2 documents uploaded successfully"
    );
  });

  test("single mode: file input is not multiple and a multi-file drop is rejected", async () => {
    create(false);
    expect((host.querySelector("input[type=file]") as HTMLInputElement).multiple).toBe(false);

    drop(host, [pdf("a.pdf"), pdf("b.pdf")]);
    await flush();

    expect(host.querySelectorAll(".du-file-item").length).toBe(0);
    expect((host.querySelector(".du-notice") as HTMLElement).hidden).toBe(false);
    expect(host.querySelector(".du-notice")!.textContent).toContain("Only one file");
  });

  test("single mode: the drop zone locks after one file and unlocks when it is removed", async () => {
    create(false);
    const zone = host.querySelector(".du-dropzone") as HTMLElement;

    drop(host, [pdf("a.pdf")]);
    await flush();
    expect(host.querySelectorAll(".du-file-item").length).toBe(1);
    expect(zone.classList.contains("du-dropzone--disabled")).toBe(true);
    expect(host.querySelector(".du-status-text")!.textContent).toBe("Document uploaded successfully");

    drop(host, [pdf("b.pdf")]);
    await flush();
    expect(host.querySelectorAll(".du-file-item").length).toBe(1);

    const remove = Array.from(host.querySelectorAll<HTMLButtonElement>(".du-file-action")).find(
      (b) => (b.firstChild as Text).textContent === "Remove"
    )!;
    remove.click();
    expect(host.querySelectorAll(".du-file-item").length).toBe(0);
    expect(zone.classList.contains("du-dropzone--disabled")).toBe(false);
  });
});
