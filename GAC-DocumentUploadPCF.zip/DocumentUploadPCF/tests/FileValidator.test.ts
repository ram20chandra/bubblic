import { FileValidator, MAX_FILE_SIZE_BYTES } from "../validation/FileValidator";
import { MockBlobUploadService } from "../services/MockBlobUploadService";
import JSZip from "jszip";

describe("FileValidator", () => {
  const validator = new FileValidator();

  function createFile(
    name: string,
    content: ArrayBuffer | Uint8Array | string,
    type = ""
  ): File {
    const blob =
      typeof content === "string"
        ? new Blob([content], { type })
        : new Blob([content], { type });
    return new File([blob], name, { type });
  }

  // ---------- PDF ----------
  test("Valid PDF signature passes", async () => {
    const header = new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x34]); // %PDF-1.4
    const file = createFile("doc.pdf", header, "application/pdf");
    const result = await validator.validate(file);
    expect(result.isValid).toBe(true);
  });

  test("Invalid PDF renamed to PDF fails signature", async () => {
    const content = new Uint8Array([0x00, 0x01, 0x02, 0x03, 0x04]);
    const file = createFile("fake.pdf", content, "application/pdf");
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("Invalid PDF signature.");
  });

  // ---------- PNG ----------
  test("Valid PNG signature passes", async () => {
    const header = new Uint8Array([
      0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00
    ]);
    const file = createFile("img.png", header, "image/png");
    const result = await validator.validate(file);
    expect(result.isValid).toBe(true);
  });

  test("Invalid PNG renamed to PNG fails", async () => {
    const content = new Uint8Array([0xff, 0xd8, 0xff]); // JPEG header
    const file = createFile("fake.png", content, "image/png");
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("Invalid image signature.");
  });

  // ---------- JPG ----------
  test("Valid JPG signature passes", async () => {
    const header = new Uint8Array([0xff, 0xd8, 0xff, 0xe0]);
    const file = createFile("photo.jpg", header, "image/jpeg");
    const result = await validator.validate(file);
    expect(result.isValid).toBe(true);
  });

  test("Invalid JPG renamed to JPG fails", async () => {
    const content = new Uint8Array([0x89, 0x50, 0x4e, 0x47]);
    const file = createFile("fake.jpg", content, "image/jpeg");
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("Invalid image signature.");
  });

  // ---------- DOCX ----------
  test("Valid DOCX structure passes", async () => {
    const zip = new JSZip();
    zip.file("[Content_Types].xml", '<?xml version="1.0"?><Types></Types>');
    zip.file("word/document.xml", '<?xml version="1.0"?><w:document></w:document>');
    zip.file("_rels/.rels", '<?xml version="1.0"?><Relationships></Relationships>');
    const blob = await zip.generateAsync({ type: "blob" });
    const file = new File([blob], "valid.docx", {
      type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    });
    const result = await validator.validate(file);
    expect(result.isValid).toBe(true);
  });

  test("Invalid DOCX ZIP structure fails", async () => {
    // Valid ZIP signature but missing required Office parts
    const zip = new JSZip();
    zip.file("random.txt", "hello");
    const blob = await zip.generateAsync({ type: "blob" });
    const file = new File([blob], "bad.docx", {
      type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    });
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("Invalid Office document structure.");
  });

  // ---------- XLSX ----------
  test("Valid XLSX structure passes", async () => {
    const zip = new JSZip();
    zip.file("[Content_Types].xml", '<?xml version="1.0"?><Types></Types>');
    zip.file("xl/workbook.xml", '<?xml version="1.0"?><workbook></workbook>');
    zip.file("_rels/.rels", '<?xml version="1.0"?><Relationships></Relationships>');
    const blob = await zip.generateAsync({ type: "blob" });
    const file = new File([blob], "valid.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    });
    const result = await validator.validate(file);
    expect(result.isValid).toBe(true);
  });

  test("Invalid XLSX ZIP structure fails", async () => {
    const zip = new JSZip();
    zip.file("not-office.txt", "data");
    const blob = await zip.generateAsync({ type: "blob" });
    const file = new File([blob], "bad.xlsx", {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    });
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("Invalid Office document structure.");
  });

  // ---------- Extension & MIME ----------
  test("Unsupported extension fails", async () => {
    const file = createFile("script.exe", new Uint8Array([0x4d, 0x5a]), "application/octet-stream");
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("Unsupported file extension.");
  });

  test("MIME type mismatch fails", async () => {
    const header = new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d]);
    const file = createFile("doc.pdf", header, "image/png"); // wrong MIME
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("MIME type does not match the extension.");
  });

  // ---------- Size & empty ----------
  test("Empty file fails", async () => {
    const file = createFile("empty.pdf", new Uint8Array(0), "application/pdf");
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("Empty files are not allowed.");
  });

  test("File greater than 32 MB fails", async () => {
    // We cannot allocate 33 MB easily in every environment; mock size via Object.defineProperty
    const header = new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d]);
    const file = createFile("big.pdf", header, "application/pdf");
    Object.defineProperty(file, "size", { value: MAX_FILE_SIZE_BYTES + 1 });
    const result = await validator.validate(file);
    expect(result.isValid).toBe(false);
    expect(result.errorMessage).toBe("File exceeds 32 MB.");
  });

  test("File exactly 32 MB is allowed (signature still checked)", async () => {
    const header = new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31]);
    const file = createFile("exact.pdf", header, "application/pdf");
    Object.defineProperty(file, "size", { value: MAX_FILE_SIZE_BYTES });
    const result = await validator.validate(file);
    expect(result.isValid).toBe(true);
  });
});

describe("MockBlobUploadService", () => {
  test("Upload success reaches 100% and returns reference", (done) => {
    const service = new MockBlobUploadService();
    service.failureRate = 0;
    service.simulatedDurationMs = 200;

    const file = new File(["hello"], "test.pdf", { type: "application/pdf" });
    let lastProgress = -1;

    service.upload(
      file,
      (p) => {
        lastProgress = p;
      },
      (result) => {
        expect(result.status).toBe("success");
        expect(result.uploadReference).toMatch(/^mock-ref-/);
        expect(lastProgress).toBe(100);
        done();
      },
      () => {
        done.fail("Should not fail");
      }
    );
  });

  test("Upload failure can be simulated", (done) => {
    const service = new MockBlobUploadService();
    service.failureRate = 1; // always fail
    service.simulatedDurationMs = 150;

    const file = new File(["hello"], "test.pdf", { type: "application/pdf" });

    service.upload(
      file,
      () => {},
      () => {
        done.fail("Should not succeed");
      },
      (err) => {
        expect(err).toContain("Simulated upload failure");
        done();
      }
    );
  });

  test("Upload cancellation stops progress", (done) => {
    const service = new MockBlobUploadService();
    service.failureRate = 0;
    service.simulatedDurationMs = 2000;

    const file = new File(["hello"], "test.pdf", { type: "application/pdf" });
    let completed = false;

    const uploadId = service.upload(
      file,
      () => {},
      () => {
        completed = true;
      },
      () => {
        completed = true;
      }
    );

    setTimeout(() => {
      service.cancel(uploadId);
      setTimeout(() => {
        expect(completed).toBe(false);
        done();
      }, 300);
    }, 50);
  });
});
