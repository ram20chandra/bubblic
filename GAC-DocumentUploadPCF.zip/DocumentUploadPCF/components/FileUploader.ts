import {
  FileValidator,
  ALLOWED_EXTENSIONS,
  MAX_FILE_SIZE_BYTES
} from "../validation/FileValidator";
import { IUploadService, UploadResult } from "../services/IUploadService";
import {
  IFileItem,
  IFileUploadMetadata,
  serializeMetadata
} from "../models/UploadMetadata";
import { UploadConfig } from "../config/UploadConfig";
import { UploadProgress, FileRowAction, FileRowState } from "./UploadProgress";

export interface FileUploaderOptions {
  /** Overrides UploadConfig.allowMultiple (mainly useful for tests). */
  allowMultiple?: boolean;
  /** true = uploads are simulated; shows a "Test mode" banner so it can never go unnoticed. */
  testMode?: boolean;
}

const CLOUD_UPLOAD_ICON =
  '<svg viewBox="0 0 48 48" width="40" height="40" fill="none" stroke="currentColor" stroke-width="2.4" ' +
  'stroke-linecap="round" stroke-linejoin="round" focusable="false" aria-hidden="true">' +
  '<path d="M15 35.5a8.5 8.5 0 0 1-1.6-16.85A11.5 11.5 0 0 1 35.6 17 9.25 9.25 0 0 1 34 35.5"/>' +
  '<path d="M24 41V25"/><path d="m18.5 30.5 5.5-5.5 5.5 5.5"/></svg>';

const CHECK_ICON =
  '<svg viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="currentColor" ' +
  'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" focusable="false" aria-hidden="true">' +
  '<circle cx="10" cy="10" r="8.5"/><path d="m6.2 10.3 2.6 2.6 5-5.2"/></svg>';

const ALERT_ICON =
  '<svg viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="currentColor" ' +
  'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" focusable="false" aria-hidden="true">' +
  '<circle cx="10" cy="10" r="8.5"/><path d="M10 5.8v5"/><path d="M10 14.2h.01"/></svg>';

const NOTICE_TIMEOUT_MS = 6000;

let instanceCounter = 0;

/**
 * Main UI component: drag-and-drop / browse upload with validation, progress,
 * cancel / retry / remove. Supports multi-file (default) and single-file mode.
 *
 * Markup uses Web Experience Toolkit (WET / GCWeb) classes - .label, .btn,
 * .alert, .wb-inv, .text-* - so a WET-themed site restyles it automatically;
 * css/DocumentUpload.css only supplies zero-specificity fallbacks.
 */
export class FileUploader {
  private readonly allowMultiple: boolean;

  private container: HTMLDivElement;
  private dropZone: HTMLDivElement;
  private dropTitle: HTMLParagraphElement;
  private dropSub: HTMLParagraphElement;
  private browseBtn: HTMLButtonElement;
  private fileInput: HTMLInputElement;
  private noticeEl: HTMLDivElement;
  private noticeText: HTMLParagraphElement;
  private fileListContainer: HTMLDivElement;
  private statusEl: HTMLParagraphElement;
  private statusIcon: HTMLSpanElement;
  private statusText: HTMLSpanElement;

  private files: Map<string, IFileItem> = new Map();
  private progressComponents: Map<string, UploadProgress> = new Map();
  private validator = new FileValidator();
  private uploadService: IUploadService;
  private onMetadataChange: (json: string) => void;
  private activeUploadIds: Map<string, string> = new Map(); // fileId -> uploadId

  private noticeTimer: number | undefined;
  private dragDepth = 0;

  constructor(
    parent: HTMLElement,
    uploadService: IUploadService,
    onMetadataChange: (json: string) => void,
    options: FileUploaderOptions = {}
  ) {
    this.uploadService = uploadService;
    this.onMetadataChange = onMetadataChange;
    this.allowMultiple =
      options.allowMultiple !== undefined ? options.allowMultiple : UploadConfig.allowMultiple;

    const uid = ++instanceCounter;
    const titleId = `du-title-${uid}`;
    const hintId = `du-accepted-${uid}`;

    const maxMb = Math.round(MAX_FILE_SIZE_BYTES / (1024 * 1024));
    const acceptedList = ALLOWED_EXTENSIONS.map((e) => e.toUpperCase()).join(", ");

    // ---- Card ----
    this.container = document.createElement("div");
    this.container.className = "du-container";
    this.container.setAttribute("role", "group");
    this.container.setAttribute("aria-labelledby", titleId);

    // ---- Header: title + size badge ----
    const header = document.createElement("div");
    header.className = "du-header";

    const title = document.createElement("p");
    title.id = titleId;
    title.className = "du-title h4";
    title.textContent = this.allowMultiple ? "Upload documents" : "Upload document";

    const badge = document.createElement("span");
    badge.className = "label label-info du-badge";
    badge.textContent = `${maxMb} MB max`;

    header.appendChild(title);
    header.appendChild(badge);

    // ---- Test-mode banner (only when uploads are simulated) ----
    let testBanner: HTMLDivElement | null = null;
    if (options.testMode) {
      testBanner = document.createElement("div");
      testBanner.className = "alert alert-info du-testmode";
      testBanner.setAttribute("role", "note");
      const bannerText = document.createElement("p");
      bannerText.textContent = "Test mode: uploads are simulated and no files are sent anywhere.";
      testBanner.appendChild(bannerText);
    }

    // ---- Drop zone ----
    this.dropZone = document.createElement("div");
    this.dropZone.className = "du-dropzone";

    const icon = document.createElement("span");
    icon.className = "du-dropzone-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.innerHTML = CLOUD_UPLOAD_ICON;

    this.dropTitle = document.createElement("p");
    this.dropTitle.className = "du-dropzone-title";

    this.dropSub = document.createElement("p");
    this.dropSub.className = "du-dropzone-sub";

    this.browseBtn = document.createElement("button");
    this.browseBtn.type = "button";
    this.browseBtn.className = "btn btn-default du-browse";
    this.browseBtn.textContent = this.allowMultiple ? "Browse files" : "Browse file";
    this.browseBtn.setAttribute("aria-describedby", hintId);
    this.browseBtn.addEventListener("click", (e) => {
      e.preventDefault();
      if (this.isLocked()) {
        this.showNotice("Remove the current file before adding another.");
        return;
      }
      this.fileInput.click();
    });

    this.dropZone.appendChild(icon);
    this.dropZone.appendChild(this.dropTitle);
    this.dropZone.appendChild(this.dropSub);
    this.dropZone.appendChild(this.browseBtn);

    // ---- Hidden file input (the Browse button is the only keyboard stop) ----
    this.fileInput = document.createElement("input");
    this.fileInput.type = "file";
    this.fileInput.multiple = this.allowMultiple;
    this.fileInput.accept = ALLOWED_EXTENSIONS.map((e) => `.${e}`).join(",");
    this.fileInput.className = "du-file-input";
    this.fileInput.tabIndex = -1;
    this.fileInput.setAttribute("aria-hidden", "true");
    this.fileInput.addEventListener("change", () => this.handleFileSelect());

    // ---- Accepted types caption ----
    const accepted = document.createElement("p");
    accepted.id = hintId;
    accepted.className = "du-accepted";
    accepted.textContent = `Accepted: ${acceptedList} · Maximum ${maxMb} MB per file`;

    // ---- Notice (rejections such as "only one file") ----
    this.noticeEl = document.createElement("div");
    this.noticeEl.className = "alert alert-warning du-notice";
    this.noticeEl.setAttribute("role", "alert");
    this.noticeEl.hidden = true;
    this.noticeText = document.createElement("p");
    this.noticeEl.appendChild(this.noticeText);

    // ---- File list ----
    this.fileListContainer = document.createElement("div");
    this.fileListContainer.className = "du-file-list";
    this.fileListContainer.setAttribute("role", "list");
    this.fileListContainer.setAttribute("aria-label", "Selected files");

    // ---- Overall status ----
    this.statusEl = document.createElement("p");
    this.statusEl.className = "du-status";
    this.statusEl.setAttribute("role", "status");
    this.statusEl.hidden = true;
    this.statusIcon = document.createElement("span");
    this.statusIcon.className = "du-status-icon";
    this.statusIcon.setAttribute("aria-hidden", "true");
    this.statusText = document.createElement("span");
    this.statusText.className = "du-status-text";
    this.statusEl.appendChild(this.statusIcon);
    this.statusEl.appendChild(this.statusText);

    this.container.appendChild(header);
    if (testBanner) this.container.appendChild(testBanner);
    this.container.appendChild(this.dropZone);
    this.container.appendChild(this.fileInput);
    this.container.appendChild(accepted);
    this.container.appendChild(this.noticeEl);
    this.container.appendChild(this.fileListContainer);
    this.container.appendChild(this.statusEl);

    parent.appendChild(this.container);

    this.attachDropHandlers();
    this.refreshDropzoneState();
  }

  // ------------------------------------------------------------------
  // Drag and drop / selection
  // ------------------------------------------------------------------

  private attachDropHandlers(): void {
    const prevent = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
    };

    this.dropZone.addEventListener("dragenter", (e) => {
      prevent(e);
      this.dragDepth++;
      if (!this.isLocked()) this.dropZone.classList.add("du-dropzone--active");
    });
    this.dropZone.addEventListener("dragover", (e) => {
      prevent(e);
      if (e.dataTransfer) {
        e.dataTransfer.dropEffect = this.isLocked() ? "none" : "copy";
      }
    });
    this.dropZone.addEventListener("dragleave", (e) => {
      prevent(e);
      this.dragDepth = Math.max(0, this.dragDepth - 1);
      if (this.dragDepth === 0) this.dropZone.classList.remove("du-dropzone--active");
    });
    this.dropZone.addEventListener("drop", (e) => {
      prevent(e);
      this.dragDepth = 0;
      this.dropZone.classList.remove("du-dropzone--active");
      if (e.dataTransfer && e.dataTransfer.files) {
        void this.processFiles(Array.from(e.dataTransfer.files));
      }
    });
  }

  private handleFileSelect(): void {
    if (this.fileInput.files) {
      const picked = Array.from(this.fileInput.files);
      this.fileInput.value = ""; // allow re-selecting the same file
      void this.processFiles(picked);
    }
  }

  // ------------------------------------------------------------------
  // Single-file mode helpers
  // ------------------------------------------------------------------

  /** True when a file is occupying the single slot (in progress or uploaded). */
  private isSlotOccupied(): boolean {
    return Array.from(this.files.values()).some(
      (f) =>
        f.metadata.validationStatus !== "invalid" &&
        (f.metadata.uploadStatus === "validating" ||
          f.metadata.uploadStatus === "pending" ||
          f.metadata.uploadStatus === "uploading" ||
          f.metadata.uploadStatus === "success")
    );
  }

  private isLocked(): boolean {
    return !this.allowMultiple && this.isSlotOccupied();
  }

  private refreshDropzoneState(): void {
    const locked = this.isLocked();
    this.dropZone.classList.toggle("du-dropzone--disabled", locked);
    this.dropZone.setAttribute("aria-disabled", locked ? "true" : "false");
    this.browseBtn.classList.toggle("disabled", locked);
    this.browseBtn.setAttribute("aria-disabled", locked ? "true" : "false");

    this.dropTitle.textContent = this.allowMultiple
      ? "Drag and drop your files here"
      : "Drag and drop your file here";
    this.dropSub.textContent = locked
      ? "Remove the current file to choose another."
      : "or browse your computer";
  }

  // ------------------------------------------------------------------
  // Notice (transient rejection message)
  // ------------------------------------------------------------------

  private showNotice(message: string): void {
    this.noticeText.textContent = message;
    this.noticeEl.hidden = false;
    if (this.noticeTimer !== undefined) window.clearTimeout(this.noticeTimer);
    this.noticeTimer = window.setTimeout(() => this.clearNotice(), NOTICE_TIMEOUT_MS);
  }

  private clearNotice(): void {
    if (this.noticeTimer !== undefined) {
      window.clearTimeout(this.noticeTimer);
      this.noticeTimer = undefined;
    }
    this.noticeEl.hidden = true;
    this.noticeText.textContent = "";
  }

  // ------------------------------------------------------------------
  // File processing
  // ------------------------------------------------------------------

  private async processFiles(fileList: File[]): Promise<void> {
    if (fileList.length === 0) return;
    this.clearNotice();

    if (!this.allowMultiple) {
      if (fileList.length > 1) {
        this.showNotice("Only one file can be uploaded at a time. Please select a single file.");
        return;
      }
      if (this.isSlotOccupied()) {
        this.showNotice("Remove the current file before adding another.");
        return;
      }
      // Whatever is left is a failed / cancelled / invalid file: replace it.
      for (const stale of Array.from(this.files.values())) {
        this.removeFile(stale);
      }
    }

    for (const file of fileList) {
      // Prevent obvious duplicates by name+size
      const already = Array.from(this.files.values()).some(
        (f) => f.file.name === file.name && f.file.size === file.size
      );
      if (already) {
        continue;
      }

      const id = `file-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      const extension = file.name.split(".").pop()?.toLowerCase() || "";

      const item: IFileItem = {
        id,
        file,
        metadata: {
          fileName: file.name,
          fileSize: file.size,
          extension,
          uploadReference: null,
          uploadStatus: "validating",
          uploadTimestamp: null,
          validationStatus: "pending",
          errorMessage: null
        },
        progress: 0,
        isUploading: false,
        canRetry: false,
        canCancel: false
      };

      this.files.set(id, item);
      this.renderFileItem(item);
      this.commit(); // locks the drop zone right away in single-file mode

      const result = await this.validator.validate(file);

      // The user may have removed the row while validation was running.
      if (!this.files.has(id)) continue;

      if (!result.isValid) {
        item.metadata.validationStatus = "invalid";
        item.metadata.uploadStatus = "failed";
        item.metadata.errorMessage = result.errorMessage;
        this.updateFileItemUI(item);
        this.commit();
        continue;
      }

      item.metadata.validationStatus = "valid";
      item.metadata.uploadStatus = "pending";
      this.updateFileItemUI(item);
      this.commit();

      // Auto-start upload
      this.runUpload(item);
    }
  }

  /** Starts (or, when `retryOf` is given, retries) the upload for one item. */
  private runUpload(item: IFileItem, retryOf?: string): void {
    item.isUploading = true;
    item.canCancel = true;
    item.canRetry = false;
    item.metadata.uploadStatus = "uploading";
    item.metadata.errorMessage = null;
    item.statusText = null;
    item.progress = 0;
    this.updateFileItemUI(item);
    this.commit();

    const onStatus = (text: string) => {
      item.statusText = text;
      this.updateFileItemUI(item);
    };
    const onProgress = (progress: number) => {
      item.progress = progress;
      this.updateFileItemUI(item);
    };
    const onComplete = (result: UploadResult) => {
      item.isUploading = false;
      item.canCancel = false;
      item.canRetry = false;
      item.progress = 100;
      item.metadata.uploadStatus = result.status;
      item.metadata.uploadReference = result.uploadReference;
      item.metadata.uploadTimestamp = result.timestamp;
      item.metadata.errorMessage = null;
      item.statusText = null;
      this.activeUploadIds.delete(item.id);
      this.updateFileItemUI(item);
      this.commit();
    };
    const onError = (error: string) => {
      item.isUploading = false;
      item.canCancel = false;
      item.canRetry = true;
      item.metadata.uploadStatus = "failed";
      item.metadata.errorMessage = error;
      item.statusText = null;
      this.activeUploadIds.delete(item.id);
      this.updateFileItemUI(item);
      this.commit();
    };

    const uploadId =
      retryOf !== undefined
        ? this.uploadService.retry(item.file, retryOf, onProgress, onComplete, onError, onStatus)
        : this.uploadService.upload(item.file, onProgress, onComplete, onError, onStatus);

    this.activeUploadIds.set(item.id, uploadId);
  }

  private cancelUpload(item: IFileItem): void {
    const uploadId = this.activeUploadIds.get(item.id);
    if (uploadId) {
      this.uploadService.cancel(uploadId);
      this.activeUploadIds.delete(item.id);
    }
    item.isUploading = false;
    item.canCancel = false;
    item.canRetry = true;
    item.metadata.uploadStatus = "cancelled";
    item.metadata.errorMessage = "Upload cancelled by user.";
    item.statusText = null;
    this.updateFileItemUI(item);
    this.commit();
  }

  private retryUpload(item: IFileItem): void {
    const previousId = this.activeUploadIds.get(item.id) || "";
    this.runUpload(item, previousId);
  }

  private removeFile(item: IFileItem): void {
    if (item.isUploading) {
      const uploadId = this.activeUploadIds.get(item.id);
      if (uploadId) this.uploadService.cancel(uploadId);
    }
    const prog = this.progressComponents.get(item.id);
    if (prog) {
      prog.remove();
      this.progressComponents.delete(item.id);
    }
    this.files.delete(item.id);
    this.activeUploadIds.delete(item.id);
    this.commit();
  }

  // ------------------------------------------------------------------
  // Rendering
  // ------------------------------------------------------------------

  private renderFileItem(item: IFileItem): void {
    const progress = new UploadProgress(this.fileListContainer);
    this.progressComponents.set(item.id, progress);
    this.updateFileItemUI(item);
  }

  private updateFileItemUI(item: IFileItem): void {
    const row = this.progressComponents.get(item.id);
    if (!row) return;

    const status = item.metadata.uploadStatus;
    let state: FileRowState = status;
    let message: string;

    switch (status) {
      case "validating":
        message = "Validating...";
        break;
      case "pending":
        message = "Ready to upload";
        break;
      case "uploading":
        message = item.statusText || "Uploading...";
        break;
      case "success":
        message = "Uploaded";
        break;
      case "cancelled":
        message = "Cancelled";
        break;
      default:
        message = item.metadata.errorMessage || "Upload failed";
        break;
    }

    if (item.metadata.validationStatus === "invalid") {
      state = "failed";
      message = item.metadata.errorMessage || "Validation failed";
    }

    const actions: FileRowAction[] = [];
    if (item.canCancel) {
      actions.push({ label: "Cancel", onClick: () => this.cancelUpload(item) });
    }
    if (item.canRetry) {
      actions.push({ label: "Retry", onClick: () => this.retryUpload(item) });
    }
    if (status !== "uploading") {
      actions.push({ label: "Remove", onClick: () => this.removeFile(item) });
    }

    row.update({
      fileName: item.metadata.fileName,
      extension: item.metadata.extension,
      sizeBytes: item.metadata.fileSize,
      progress: item.progress,
      state,
      message,
      actions
    });
  }

  /** Called after every state change: emit metadata, refresh footer + drop zone. */
  private commit(): void {
    this.emitMetadata();
    this.updateOverallStatus();
    this.refreshDropzoneState();
  }

  private emitMetadata(): void {
    const meta: IFileUploadMetadata[] = Array.from(this.files.values()).map(
      (f) => f.metadata
    );
    this.onMetadataChange(serializeMetadata(meta));
  }

  private setStatus(kind: "success" | "error" | "info" | "none", text: string): void {
    if (kind === "none") {
      this.statusEl.hidden = true;
      this.statusText.textContent = "";
      this.statusIcon.innerHTML = "";
      return;
    }
    this.statusEl.hidden = false;
    const tone = kind === "success" ? "text-success" : kind === "error" ? "text-danger" : "text-info";
    this.statusEl.className = `du-status du-status--${kind} ${tone}`;
    this.statusIcon.innerHTML = kind === "success" ? CHECK_ICON : kind === "error" ? ALERT_ICON : "";
    this.statusText.textContent = text;
  }

  private updateOverallStatus(): void {
    const items = Array.from(this.files.values());
    if (items.length === 0) {
      this.setStatus("none", "");
      return;
    }

    const total = items.length;
    const uploading = items.filter((i) => i.metadata.uploadStatus === "uploading").length;
    const busy = items.filter(
      (i) =>
        i.metadata.uploadStatus === "validating" || i.metadata.uploadStatus === "pending"
    ).length;
    const success = items.filter((i) => i.metadata.uploadStatus === "success").length;
    const notUploaded = total - success - uploading - busy;

    if (uploading > 0 || busy > 0) {
      this.setStatus(
        "info",
        total === 1 ? "Uploading document..." : `Uploading ${uploading} of ${total} documents...`
      );
    } else if (notUploaded > 0 && success === 0) {
      this.setStatus(
        "error",
        total === 1
          ? "Upload failed. Retry or remove the file."
          : "No documents were uploaded. Retry or remove the files."
      );
    } else if (notUploaded > 0) {
      this.setStatus("error", `${success} uploaded, ${notUploaded} not uploaded.`);
    } else {
      this.setStatus(
        "success",
        total === 1
          ? "Document uploaded successfully"
          : `All ${total} documents uploaded successfully`
      );
    }
  }

  public destroy(): void {
    if (this.noticeTimer !== undefined) window.clearTimeout(this.noticeTimer);
    // Cancel any active uploads
    this.activeUploadIds.forEach((uploadId) => this.uploadService.cancel(uploadId));
    this.activeUploadIds.clear();
    this.files.clear();
    this.progressComponents.clear();
    this.container.remove();
  }
}
