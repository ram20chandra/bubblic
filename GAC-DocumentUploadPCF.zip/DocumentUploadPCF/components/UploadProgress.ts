/**
 * Renders a single file row: type icon, name, "size · status" line, percentage,
 * a native <progress> bar and the per-file actions.
 *
 * Markup follows the Web Experience Toolkit (WET / GCWeb, Bootstrap 3 based):
 *  - native HTML5 <progress> with a .wb-inv text alternative (WET does not use .progress-bar)
 *  - .btn .btn-link for actions, with the file name in a .wb-inv suffix so each
 *    button has a unique accessible name
 *
 * Pure DOM helper – no framework.
 */

export type FileRowState =
  | "validating"
  | "pending"
  | "uploading"
  | "success"
  | "failed"
  | "cancelled";

export interface FileRowAction {
  label: string;
  onClick: () => void;
}

export interface FileRowView {
  fileName: string;
  extension: string;
  sizeBytes: number;
  progress: number; // 0-100
  state: FileRowState;
  message: string; // text after "size ·"
  actions: FileRowAction[];
}

interface IconStyle {
  color: string;
  label: string;
}

/** Whitelist: the label drawn in the icon never comes from user input. */
const ICON_STYLES: Record<string, IconStyle> = {
  pdf: { color: "#d13438", label: "PDF" },
  docx: { color: "#2b579a", label: "DOC" },
  xlsx: { color: "#217346", label: "XLS" },
  png: { color: "#8764b8", label: "PNG" },
  jpg: { color: "#c4651a", label: "JPG" },
  jpeg: { color: "#c4651a", label: "JPG" }
};
const GENERIC_ICON: IconStyle = { color: "#605e5c", label: "FILE" };

const CHECK_ICON =
  '<svg viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="currentColor" ' +
  'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" focusable="false" aria-hidden="true">' +
  '<circle cx="10" cy="10" r="8.5"/><path d="m6.2 10.3 2.6 2.6 5-5.2"/></svg>';

function fileIconSvg(extension: string): string {
  const style = ICON_STYLES[extension] || GENERIC_ICON;
  const c = style.color;
  return (
    '<svg viewBox="0 0 28 34" width="26" height="32" focusable="false" aria-hidden="true">' +
    `<path d="M3 1h14.5L27 10.5V31a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2z" fill="#fff" stroke="${c}" stroke-width="2"/>` +
    `<path d="M17.5 1v9.5H27" fill="none" stroke="${c}" stroke-width="2" stroke-linejoin="round"/>` +
    `<rect x="1" y="17" width="26" height="10" rx="1.5" fill="${c}"/>` +
    `<text x="14" y="24.6" font-size="7.2" font-weight="700" fill="#fff" text-anchor="middle" font-family="Arial,Helvetica,sans-serif">${style.label}</text>` +
    "</svg>"
  );
}

export class UploadProgress {
  private container: HTMLDivElement;
  private iconEl: HTMLSpanElement;
  private nameEl: HTMLSpanElement;
  private metaEl: HTMLSpanElement;
  private trailingEl: HTMLSpanElement;
  private progressEl: HTMLProgressElement;
  private progressAltEl: HTMLSpanElement;
  private actionsEl: HTMLDivElement;

  private currentIconExt = "";
  private currentActionsKey = "";

  constructor(parent: HTMLElement) {
    this.container = document.createElement("div");
    this.container.className = "du-file-item";
    this.container.setAttribute("role", "listitem");

    const row = document.createElement("div");
    row.className = "du-file-row";

    this.iconEl = document.createElement("span");
    this.iconEl.className = "du-file-icon";
    this.iconEl.setAttribute("aria-hidden", "true");

    const main = document.createElement("div");
    main.className = "du-file-main";

    this.nameEl = document.createElement("span");
    this.nameEl.className = "du-file-name";

    this.metaEl = document.createElement("span");
    this.metaEl.className = "du-file-meta";

    main.appendChild(this.nameEl);
    main.appendChild(this.metaEl);

    this.trailingEl = document.createElement("span");
    this.trailingEl.className = "du-file-trailing";
    this.trailingEl.setAttribute("aria-hidden", "true");

    row.appendChild(this.iconEl);
    row.appendChild(main);
    row.appendChild(this.trailingEl);

    // WET: native <progress> with a visually-hidden text alternative
    this.progressEl = document.createElement("progress");
    this.progressEl.className = "du-progress";
    this.progressEl.max = 100;
    this.progressEl.value = 0;
    this.progressAltEl = document.createElement("span");
    this.progressAltEl.className = "wb-inv";
    this.progressEl.appendChild(this.progressAltEl);

    this.actionsEl = document.createElement("div");
    this.actionsEl.className = "du-file-actions";

    this.container.appendChild(row);
    this.container.appendChild(this.progressEl);
    this.container.appendChild(this.actionsEl);

    parent.appendChild(this.container);
  }

  update(view: FileRowView): void {
    const pct = Math.min(100, Math.max(0, Math.floor(view.progress)));

    this.container.className = `du-file-item du-file-item--${view.state}`;

    if (this.currentIconExt !== view.extension) {
      this.iconEl.innerHTML = fileIconSvg(view.extension);
      this.currentIconExt = view.extension;
    }

    this.nameEl.textContent = view.fileName;
    this.nameEl.title = view.fileName;
    this.metaEl.textContent = `${formatSize(view.sizeBytes)} · ${view.message}`;

    // Trailing: percentage while uploading, check mark when done, nothing otherwise
    if (view.state === "uploading") {
      this.trailingEl.textContent = `${pct}%`;
      this.trailingEl.className = "du-file-trailing du-file-trailing--pct";
    } else if (view.state === "success") {
      this.trailingEl.innerHTML = CHECK_ICON;
      this.trailingEl.className = "du-file-trailing du-file-trailing--done";
    } else {
      this.trailingEl.textContent = "";
      this.trailingEl.className = "du-file-trailing";
    }

    this.progressEl.value = pct;
    this.progressEl.setAttribute("aria-label", view.fileName);
    this.progressAltEl.textContent = `${pct}%`;

    this.setActions(view);
  }

  remove(): void {
    this.container.remove();
  }

  /** Rebuilds the buttons only when the set of actions changes (not on every progress tick). */
  private setActions(view: FileRowView): void {
    const key = view.actions.map((a) => a.label).join("|");
    if (key === this.currentActionsKey) {
      // Handlers capture the item, so the existing buttons stay valid.
      return;
    }
    this.currentActionsKey = key;

    this.actionsEl.textContent = "";
    for (const action of view.actions) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "btn btn-link btn-sm du-file-action";
      b.appendChild(document.createTextNode(action.label));
      const hidden = document.createElement("span");
      hidden.className = "wb-inv";
      hidden.textContent = ` ${view.fileName}`;
      b.appendChild(hidden);
      b.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        action.onClick();
      });
      this.actionsEl.appendChild(b);
    }
  }
}

export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
