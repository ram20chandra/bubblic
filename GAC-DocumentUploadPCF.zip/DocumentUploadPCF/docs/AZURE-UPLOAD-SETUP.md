# Azure upload setup

How the pieces fit:

```
PCF control ──creates row──► Dataverse "Upload Request" (metadata only, never the file)
                                  │ Flow 1: validate + write a write-only SAS URL on the row
PCF control ◄──reads SAS──────────┘
PCF control ──PUT file (SAS)──► Azure Blob  "quarantine"/<rowId>/<file>
                                  │ Microsoft Defender for Storage: on-upload malware scan
                                  ▼ Flow 2: Clean  → Graph upload to SharePoint → link on your record
                                            Infected → move to "infected" container, alert
PCF control ◄──polls the row until Flow 2 sets Clean / Infected / Failed
```

Do the sections in order: 1 → 2 → 3 → 4 → 5 → 6/7.

---

## 1. Placeholders - what to enter

### 1a. In the control: `config/AzureUploadConfig.ts` (3 values, then 1 switch)

**Already set in this build:** `publisherPrefix: "gac"`, `storageAccountName: "gadkalyanstorageaccount"`, `containerName: "quarantine"`.
The only thing left to change is `useMockService` → `false` once the table, storage and Flow 1 exist.
Where this guide shows `<prefix>`, use `gac`; where it shows `<STORAGE_ACCOUNT>`, use `gadkalyanstorageaccount`; `<CONTAINER>` = `quarantine`.

| Setting | What to enter | Where to find it | Example |
|---|---|---|---|
| `publisherPrefix` | Customization prefix of the publisher that owns the Upload Request table. Lower-case, no underscore. | make.powerapps.com → **Solutions → Publishers →** your publisher → *Prefix* | `cntso` |
| `storageAccountName` | The storage account **name only** (not the URL). The control builds `<name>.blob.core.windows.net` itself and refuses any other host. | Azure portal → **Storage accounts** | `contosodocs` |
| `containerName` | The private container the SAS links point at. | Azure portal → storage account → **Containers** | `quarantine` |
| `useMockService` | `true` = test mode (simulated, blue banner, nothing sent). **Set to `false` for real uploads.** | - | `false` |

Optional settings in the same file (defaults are fine for most sites):

| Setting | Default | Change when |
|---|---|---|
| `tableLogicalName` / `entitySetName` | derived: `<prefix>_uploadrequest` / `<prefix>_uploadrequests` | you named the table differently |
| `hostMode` | `auto` | auto-detection picks the wrong host (`modelDriven` or `powerPages`) |
| `recordIdQueryParam` | `id` | your Power Pages edit page uses a different query-string name |
| `waitForScanResult` | `true` | `false` = show "Uploaded" as soon as the blob arrives; scan result is not awaited |
| `pollIntervalMs`, `sasTimeoutMs`, `scanTimeoutMs`, `blockSizeBytes` | 2 s, 2 min, 5 min, 4 MB | flows are slower / faster than that |

After editing: `npm run build`, then push/import again with a higher `version` in `ControlManifest.Input.xml`.

### 1b. On the form (control parameters, no rebuild)

| Parameter | Value |
|---|---|
| **Allow multiple files (Y/N)** | `Y` or `N` (blank = `N`) |
| **Target table logical name (Power Pages only)** | Logical name of the table the form edits, e.g. `account`. Leave blank in D365. |

### 1c. In the flows (you enter these when building Flow 1 / 2 / 3)

| Placeholder | Meaning | Where to find it |
|---|---|---|
| `<STORAGE_ACCOUNT>` / `<CONTAINER>` | Same two values as above | Azure portal |
| `<INFECTED_CONTAINER>` | Container for flagged files, e.g. `infected` | you create it (step 3) |
| `<ALLOWED_TABLES>` | List of table logical names users may attach documents to, e.g. `["account","contact"]` | your design |
| `<TENANT_ID>` | Entra tenant ID | Entra ID → Overview |
| `<GRAPH_APP_CLIENT_ID>` + secret/certificate | Entra app registration the flow uses to call Graph | step 5 |
| `<SITE_ID>` | Graph id of the SharePoint site | Graph call in step 5 |
| `<DRIVE_ID>` | Graph id of the document library | Graph call in step 5 |
| `<FOLDER>` | Top folder in the library, e.g. `Uploads` | your design |
| `<ALERT_EMAIL>` | Who is told about infected files | your design |
| `<LINK_COLUMN>` | Column on your record that stores the SharePoint link, e.g. `cntso_documentlink` | you add it to your table (step 2) |

---

## 2. Dataverse

### 2a. Upload Request table

Create in the **same solution/publisher** whose prefix you put in `publisherPrefix`.

- Display name: **Upload Request**, plural **Upload Requests**
- Schema name: `<prefix>_uploadrequest` (so the collection name is `<prefix>_uploadrequests`)
- Ownership: **User or team**. Leave attachments/notes/activities **off**.

Columns - schema names must be **exactly** these (replace `<prefix>`):

| Column (schema name) | Type | Max length | Notes |
|---|---|---|---|
| `<prefix>_name` | Single line of text (primary name) | 100 | file name (truncated) |
| `<prefix>_targettable` | Single line of text | 100 | e.g. `account` |
| `<prefix>_targetrecordid` | Single line of text | 40 | GUID of your record |
| `<prefix>_filename` | Single line of text | 400 | |
| `<prefix>_filesize` | Whole number | - | bytes |
| `<prefix>_contenttype` | Single line of text | 200 | |
| `<prefix>_status` | Single line of text | 50 | **text, not a choice** (see below) |
| `<prefix>_sasurl` | Multiple lines of text | 4000 | short-lived write link |
| `<prefix>_blobname` | Single line of text | 500 | |
| `<prefix>_errormessage` | Multiple lines of text | 1000 | shown to the user |
| `<prefix>_sharepointurl` | Single line of text (URL format) | 2000 | set by Flow 2 |

`status` is plain text on purpose: choice values contain a publisher-specific number, which would
make the flows and the control disagree. Use exactly these strings:

`Requested` → `SasIssued` → `Clean` | `Infected` | `Rejected` | `Failed` | `Cancelled`

### 2b. A column on your own record for the link

Add a **URL** (or single line of text) column to each table users attach documents to, e.g.
`<prefix>_documentlink`. This is `<LINK_COLUMN>` for Flow 2. (One column keeps only the latest link.
For several documents per record, have Flow 2 create rows in a small "Document Link" table instead.)

### 2c. Security (D365)

Security role for the people who upload: on **Upload Request** give **Create, Read, Write** at
**User** level. They need Read because the control reads its own row to get the SAS and the result.
The flows run under a service account / service principal with full access to the table.

### 2d. Housekeeping

Create a **bulk delete job** (Settings → Advanced settings → System jobs → Bulk delete) or use
Flow 3 below so Upload Request rows older than 7 days are removed.

---

## 3. Azure Storage + Defender

1. **Storage account**: StorageV2, Standard. *Allow Blob anonymous access* = **Disabled**.
   Minimum TLS 1.2. *Allow storage account key access* = **Enabled** (Flow 1's "Create SAS URI"
   action signs with the account key; if your policy forbids keys, see "No account keys" at the end).
2. **Containers** (both private): `quarantine` and `infected`.
3. **CORS** (Storage account → *Resource sharing (CORS)* → **Blob service**). Without this the
   browser blocks the upload:

   | Allowed origins | Allowed methods | Allowed headers | Exposed headers | Max age |
   |---|---|---|---|---|
   | `https://<yourorg>.crm.dynamics.com`, `https://<yoursite>.powerappsportals.com` (or your custom domain) - one per line, no trailing slash | `PUT`, `OPTIONS` | `*` | `*` | `3600` |

4. **Lifecycle rule** (Data management → Lifecycle management): delete blobs in `quarantine/` and
   `infected/` 7 days after last modification (clears leftovers).
5. **Defender for Storage** (storage account → *Microsoft Defender for Cloud* → *Settings*, or
   Defender for Cloud → Environment settings): enable the plan on this account and turn on
   **On-upload malware scanning**. Set a monthly scan cap (GB) to control cost. Check Microsoft's
   current limit on the largest file it scans - your 32 MB max is well under it.
6. **Scan results to Event Grid**: create an **Event Grid custom topic** (e.g. `defender-scan-results`)
   and point Defender's *Send scan results to an Event Grid topic* setting at it. Defender also
   writes the result as a **blob index tag** on the file - useful for checking by hand.

---

## 4. Flow 1 - issue the SAS URL

Name: `DocUpload - 1 - Issue SAS`. Run it under a service account. (Needs: Dataverse and Azure Blob
Storage connectors allowed by your DLP policy.)

**Trigger** - Dataverse: *When a row is added, modified or deleted*
- Change type: **Added** · Table name: **Upload Requests** · Scope: **Organization**

**Actions**

1. *Initialize variable* `allowedExt` (Array): `["pdf","png","jpg","jpeg","docx","xlsx"]`
2. *Initialize variable* `allowedTables` (Array): `<ALLOWED_TABLES>`, e.g. `["account","contact"]`
3. *Compose* `ext`: `toLower(last(split(triggerOutputs()?['body/<prefix>_filename'],'.')))`
4. *Compose* `safeName`:
   `replace(replace(replace(replace(replace(triggerOutputs()?['body/<prefix>_filename'],'/','_'),'\','_'),'..','_'),'?','_'),'#','_')`
5. *Condition* `Valid request?` - **And** of:
   - `contains(variables('allowedExt'), outputs('ext'))`
   - `triggerOutputs()?['body/<prefix>_filesize']` is greater than `0` and less than or equal to `33554432`
   - `contains(variables('allowedTables'), toLower(triggerOutputs()?['body/<prefix>_targettable']))`

   *Recommended extra check*: confirm the uploader may access the target record, e.g. a Dataverse
   *Perform an unbound action* → `RetrievePrincipalAccess` for the row's creator on the target record
   (see Microsoft docs for the exact parameters), and stop when access is `None`.

**If yes** - put these in a **Scope** named `Issue`:

   a. *Compose* `blobName`: `concat(triggerOutputs()?['body/<prefix>_uploadrequestid'],'/',outputs('safeName'))`
   b. Azure Blob Storage → **Create SAS URI by path (V2)**
      - Storage account: your connection (`<STORAGE_ACCOUNT>`)
      - Blob path: `concat('/<CONTAINER>/', outputs('blobName'))`
      - Permissions: **Add, Create, Write** only (no Read / Delete / List)
      - Start time: `addMinutes(utcNow(),-5)`  ·  Expiry time: `addMinutes(utcNow(),15)`
      - Protocol: **HTTPS only**
   c. Dataverse → **Update a row** (Upload Requests), row id = trigger row id:
      `<prefix>_sasurl` = the action's **Web Url** output (check the dynamic-content name),
      `<prefix>_blobname` = `outputs('blobName')`, `<prefix>_status` = `SasIssued`

   *Configure run after* on an extra *Update a row* (status `Failed`, errormessage
   `Could not prepare the upload.`) to run **only if `Issue` has failed**.

**If no** - *Update a row*: `<prefix>_status` = `Rejected`, `<prefix>_errormessage` =
`This file type, size or destination is not allowed.`

> The SAS path **must** be `/<CONTAINER>/<rowId>/<file>` - the control checks the host and container,
> and Flow 2 reads the row id from the first folder in the path.

---

## 5. Flow 2 - scan result → SharePoint → your record

Name: `DocUpload - 2 - Scan result to SharePoint`.

### 5a. One-time Graph / SharePoint setup

1. Entra ID → **App registrations → New** (`DocUpload-Graph`). Add a client secret (or certificate).
   Note `<TENANT_ID>` and `<GRAPH_APP_CLIENT_ID>`.
2. **API permissions → Microsoft Graph → Application → `Sites.Selected`** → *Grant admin consent*.
3. Find the ids (Graph Explorer, signed in as an admin):
   - `GET https://graph.microsoft.com/v1.0/sites/<tenant>.sharepoint.com:/sites/<SiteName>` → `id` = `<SITE_ID>`
   - `GET https://graph.microsoft.com/v1.0/sites/<SITE_ID>/drives` → the library's `id` = `<DRIVE_ID>`
4. Allow the app on **that site only**: `POST https://graph.microsoft.com/v1.0/sites/<SITE_ID>/permissions`
   with body
   `{"roles":["write"],"grantedToIdentities":[{"application":{"id":"<GRAPH_APP_CLIENT_ID>","displayName":"DocUpload-Graph"}}]}`
   (requires a Graph token that can manage site permissions, e.g. `Sites.FullControl.All`).

### 5b. Trigger

**Option A (fast) - Event Grid:** Azure Event Grid → *When a resource event occurs* on the custom
topic from step 3.6, event type `Microsoft.Security.MalwareScanningResult`. If the connector cannot list
your topic, build this flow as a **Logic App** with an Event Grid trigger, or use Option B.

**Option B (simple) - polling:** Azure Blob Storage → *When a blob is added or modified (properties
only) (V2)* on `<CONTAINER>`, then *Do until* the blob's index tag `Malware Scanning scan result` has a
value (*Get blob tags (V2)*, delay 10 s, up to ~5 min). Slower (polling interval), but no Event Grid setup.

Run once and **read the real event/tag field names in the run history** - the expressions below use
`data/blobUri` and `data/scanResultType`; adjust if yours differ.

### 5c. Actions

1. *Compose* `blobUri`: `triggerOutputs()?['body/data/blobUri']`
2. *Compose* `parts`: `split(outputs('blobUri'),'/')` → `[https:, , account.blob..., container, <rowId>, <file>]`
3. *Condition*: `outputs('parts')[3]` equals `<CONTAINER>` - otherwise **Terminate** (Cancelled).
4. *Compose* `rowId`: `outputs('parts')[4]` · *Compose* `fileName`: `uriComponentToString(last(outputs('parts')))`
5. Dataverse → *Get a row by ID* (Upload Requests, `rowId`). *Condition*: status equals `SasIssued`,
   otherwise **Terminate** (the user cancelled or it was already processed).
6. *Condition* **Scan clean?** `triggerOutputs()?['body/data/scanResultType']` equals `No threats found`

**Clean branch** (put in a Scope `Clean`):

   a. Azure Blob → **Get blob content using path (V2)**: `concat('/<CONTAINER>/', outputs('rowId'), '/', outputs('fileName'))`
   b. **HTTP** (Premium) - upload with Graph:
      - Method `PUT`
      - URI `https://graph.microsoft.com/v1.0/sites/<SITE_ID>/drives/<DRIVE_ID>/root:/<FOLDER>/@{body('Get_row')?['<prefix>_targettable']}/@{body('Get_row')?['<prefix>_targetrecordid']}/@{outputs('fileName')}:/content?@microsoft.graph.conflictBehavior=rename`
      - Headers `Content-Type` = `@{body('Get_row')?['<prefix>_contenttype']}`
      - Body = the blob content from step a
      - Authentication = **Active Directory OAuth**: Authority `https://login.microsoftonline.com`,
        Tenant `<TENANT_ID>`, Audience `https://graph.microsoft.com`, Client ID `<GRAPH_APP_CLIENT_ID>`, secret/cert
      - Graph creates the folders in the path automatically. A single `PUT .../content` call handles files
        well beyond your 32 MB limit, so no upload session is needed.
      - **Check a real PDF opens from SharePoint.** If it is corrupt, set Body to
        `outputs('Get_blob_content_using_path_(V2)')?['body']`.
      - The response has `webUrl` (the link) and `id`.
      - If the HTTP action is blocked by DLP, use SharePoint **Create file** (Site address, Folder path,
        File name, File content) then **Get file properties** for the link.
   c. Write the link to your record - *Switch* on `Get_row` → `<prefix>_targettable`, one case per table in
      `<ALLOWED_TABLES>`, each with *Update a row* (that table, row id = `targetrecordid`),
      `<LINK_COLUMN>` = `webUrl`. (A *Switch* is needed because the *Update a row* action wants a fixed table.)
   d. *Update a row* (Upload Requests): `<prefix>_sharepointurl` = `webUrl`, `<prefix>_status` = `Clean`
      **(do this last - it is what releases the user's progress bar)**
   e. Azure Blob → **Delete blob (V2)** the quarantine blob.

**Infected branch** (Scope `Infected`):

   a. Azure Blob → **Copy blob (V2)** from `<CONTAINER>` to `<INFECTED_CONTAINER>`, then **Delete blob (V2)** the original.
   b. *Update a row*: `<prefix>_status` = `Infected`, `<prefix>_errormessage` =
      `The file failed the security scan and was rejected.`
   c. Send an email / Teams message to `<ALERT_EMAIL>` with the file name and `rowId`.

Add a failure handler (*run after: has failed*) that sets status `Failed` with a short
`errormessage` and alerts `<ALERT_EMAIL>`. Leave the quarantine blob in place so it can be re-run.

---

## 6. Flow 3 - sweeper (scheduled, daily)

1. *List rows* (Upload Requests): filter `(<prefix>_status eq 'Requested' or <prefix>_status eq 'SasIssued') and createdon lt @{addHours(utcNow(),-2)}`
   → *Apply to each*: *Update a row* → status `Failed`, errormessage `Timed out.`
2. *List rows*: filter `createdon lt @{addDays(utcNow(),-7)}` → *Apply to each*: *Delete a row*.

---

## 7. Put the control on the form

D365 and Power Pages steps (adding the control, the Y/N parameter) are in the main README.
Specifics for this service:

**D365:** nothing else - the control uses the form's record automatically. The record must be saved first.

**Power Pages:**
1. Site settings (Portal Management app → Site Settings), for the Upload Request table:
   - `Webapi/<prefix>_uploadrequest/enabled` = `true`
   - `Webapi/<prefix>_uploadrequest/fields` = `<prefix>_name,<prefix>_targettable,<prefix>_targetrecordid,<prefix>_filename,<prefix>_filesize,<prefix>_contenttype,<prefix>_status,<prefix>_sasurl,<prefix>_blobname,<prefix>_errormessage,<prefix>_sharepointurl`
2. **Table permission** on Upload Request: privileges **Create, Read, Write**, assigned to the web role of
   your signed-in users.
3. The form must be in **Edit** mode on a URL that carries the record id (`?id=<guid>`). The control
   cannot attach files to a record that does not exist yet.
4. Set the control's **Target table logical name** parameter (e.g. `account`).

**Security note (Power Pages):** with a *Global*-scope table permission any signed-in portal user could
list other users' Upload Request rows and read an unexpired SAS link. The link is write-only, valid
15 minutes and limited to one blob, and the control clears it right after use, but for stricter
isolation add a Contact lookup to the table, set it on create, and use *Contact*-scope permission.

---

## 8. Test checklist

1. **Flow 1 alone**: create an Upload Request row by hand with status `Requested` and a `.pdf` file name →
   within seconds `status` = `SasIssued` and `sasurl` is filled.
2. **CORS / blob**: from the app, upload a small PDF; in the browser dev tools (Network) the `PUT` to
   `<account>.blob.core.windows.net` should return **201**. A blocked/CORS error means step 3.3.
3. **Defender**: the blob gets the index tag `Malware Scanning scan result = No threats found`.
4. **Flow 2**: file appears in the SharePoint folder, your record's `<LINK_COLUMN>` has the link, the row
   is `Clean`, the quarantine blob is gone, and the control shows "Document uploaded successfully".
5. **Infected path**: the control's signature check blocks a fake `.pdf`, so test Defender directly: take a row that is `SasIssued`, and in the Azure portal upload the standard **EICAR** antivirus test file (a harmless text file every scanner flags) into `<CONTAINER>/<that row id>/test.pdf`. Flow 2 should move it to `<INFECTED_CONTAINER>`, set the row to `Infected` and email `<ALERT_EMAIL>`.
6. **Rejections**: `.exe` is stopped by the control; a table not in `<ALLOWED_TABLES>` ends `Rejected`.

## 9. Troubleshooting

| Message in the control | Likely cause |
|---|---|
| "Upload is not configured yet. Set publisherPrefix, ..." | placeholders in `config/AzureUploadConfig.ts` not filled in |
| "Save the record first, then upload documents." | record not saved / no `?id=` in the Power Pages URL / Target table parameter empty |
| "Preparing the upload took too long." | Flow 1 off, failing, or slow - check its run history |
| "The upload link does not point at the configured storage account/container" | Flow 1's SAS path or account differs from `storageAccountName` / `containerName` |
| "Could not reach Azure Storage ... (CORS)" | CORS rule missing the site origin, or the method `PUT` / header rules (section 3.3) |
| "Azure rejected the upload link (403 ...)" | SAS expired (clock skew - use the -5 min start time), or permissions missing `Create/Write` |
| "The security scan is taking longer than expected..." | Defender / Event Grid / Flow 2 slow or not triggered; the file stays in quarantine and Flow 2 will still process it |
| Power Pages: "Web API create failed (403/401)" | site settings or table permission missing (section 7) |

**No account keys?** If policy forbids shared-key access, replace the *Create SAS URI by path* action
with a small Azure Function (managed identity, user-delegation SAS) that Flow 1 calls via a custom
connector. The control does not change - it only needs the SAS URL on the row.
